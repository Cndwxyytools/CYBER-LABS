# CYBER-LAB

Version organized for GitHub Pages.

## Publish
1. Create a GitHub repository.
2. Upload the contents of this folder to the repository root.
3. Go to Settings -> Pages.
4. Under Build and deployment, select Deploy from a branch.
5. Select `main` and `/ (root)`, then Save.
6. Open the GitHub Pages URL shown by GitHub.

The site entry point is `index.html`.
