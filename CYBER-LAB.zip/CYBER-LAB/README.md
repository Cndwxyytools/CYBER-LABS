# CYBER LAB

**Apprends. Expérimente. Comprends.**

Plateforme éducative de cybersécurité — prototype frontend autonome.

## Présentation

CYBER LAB est une application web locale destinée à l'apprentissage progressif de :

- Fondamentaux informatiques et Windows  
- CMD, Batch, PowerShell, Python  
- Réseaux, Web, Scraping légal, OSINT  
- Pentest légal (méthodologie), analyse de malware (simulation)  
- Blue Team et bases d'IA appliquée à la détection  

Ce n'est **pas** une certification professionnelle. Tout le contenu offensif est simulé avec des données fictives dans des environnements contrôlés.

## Installation / Lancement

### Option 1 — Fichier local

Ouvrez simplement `index.html` dans un navigateur moderne (Chrome, Firefox, Edge).

> Certaines fonctionnalités (export ZIP complet via fetch) fonctionnent mieux via un serveur local.

### Option 2 — Serveur local

```bash
# Python
python -m http.server 8080

# Node
npx serve .

# Puis ouvrir http://localhost:8080
```

## Architecture

```
CYBER-LAB/
├── index.html
├── css/styles.css
├── js/
│   ├── app.js              # SPA principale
│   ├── data/
│   │   ├── commands.js     # Fiches commandes détaillées
│   │   ├── courses.js      # Modules et leçons
│   │   ├── quizzes.js
│   │   └── labs.js
│   └── utils/
│       ├── storage.js      # localStorage (XP, progression)
│       └── terminal.js     # Terminal de simulation
├── manifest.json
└── README.md
```

## Fonctionnalités

- Dashboard avec XP, niveau, progression  
- Cours par modules (14 modules)  
- Fiches commandes CMD approfondies (syntaxe, options, exemples, cyber)  
- Terminal simulé (aucune exécution réelle)  
- Labs dont **FAKE STEALER** (données 100 % fictives)  
- Missions et CTF fictifs  
- Quiz avec explications  
- Favoris, notes, recherche globale  
- Export / import de progression  
- Page Cyber Ethics  

## Export

L'interface d'export est protégée par un code d'accès prototype : `8808`.

**Important :** ce code est visible dans le code source JavaScript. Ce n'est **pas** une sécurité cryptographique. Objectif : masquer l'UI d'export dans le contexte pédagogique.

## Mode hors-ligne

Un `manifest.json` est fourni pour une éventuelle installation PWA. Un service worker peut être ajouté pour le cache des ressources.

## Limites du prototype

- Contenu de leçons : certains cours ont un template riche ; les modules CMD, Réseaux, Malware et OSINT ont du contenu plus détaillé.  
- Le terminal simule un sous-ensemble de commandes.  
- Pas de backend : toute la progression est locale (localStorage).  

## Sécurité & éthique

- Aucune donnée réelle (mots de passe Wi-Fi, cookies, tokens) n'est extraite.  
- Aucun outil offensif opérationnel n'est fourni.  
- Les labs utilisent uniquement des simulations et des jeux de données fictifs.  
- Consultez la page **Cyber Ethics** dans l'application.

## Personnalisation

- Ajouter des commandes dans `js/data/commands.js`  
- Ajouter des cours dans `js/data/courses.js`  
- Ajouter des quiz dans `js/data/quizzes.js`  

## Licence

Prototype éducatif. À utiliser de façon responsable et légale.
