/**
 * CYBER LAB — Application principale (SPA)
 */
const App = {
  progress: null,
  currentPage: "dashboard",
  terminal: null,
  searchQuery: "",

  init() {
    this.progress = loadProgress();
    this.renderSidebar();
    this.bindGlobal();
    this.navigate("dashboard");
    this.updateHeaderStats();
    // PWA offline check
    if ("serviceWorker" in navigator) {
      // optional: register later
    }
  },

  bindGlobal() {
    document.getElementById("menu-toggle")?.addEventListener("click", () => {
      document.getElementById("sidebar").classList.toggle("open");
    });
    document.getElementById("global-search")?.addEventListener("input", (e) => {
      this.searchQuery = e.target.value.trim();
      if (this.searchQuery.length >= 2) this.navigate("search");
    });
    document.getElementById("export-cancel")?.addEventListener("click", () => {
      document.getElementById("export-modal").classList.remove("show");
    });
    document.getElementById("export-submit")?.addEventListener("click", () => {
      const pwd = document.getElementById("export-password").value;
      if (pwd === "8808") {
        document.getElementById("export-modal").classList.remove("show");
        this.navigate("export");
      } else {
        showToast("Code incorrect", "error");
      }
    });
  },

  updateHeaderStats() {
    this.progress = loadProgress();
    document.getElementById("header-xp").textContent = this.progress.xp + " XP";
    document.getElementById("header-level").textContent = "N" + this.progress.level;
  },

  renderSidebar() {
    const nav = document.getElementById("sidebar-nav");
    nav.innerHTML = `
      <div class="nav-section">
        <div class="nav-section-title">Principal</div>
        <button class="nav-item" data-page="dashboard"><span class="icon">🏠</span> Dashboard</button>
        <button class="nav-item" data-page="courses"><span class="icon">📚</span> Cours</button>
        <button class="nav-item" data-page="commands"><span class="icon">⌨️</span> Commandes</button>
        <button class="nav-item" data-page="terminal"><span class="icon">💻</span> Terminal Lab</button>
      </div>
      <div class="nav-section">
        <div class="nav-section-title">Pratique</div>
        <button class="nav-item" data-page="labs"><span class="icon">🧪</span> Labs</button>
        <button class="nav-item" data-page="missions"><span class="icon">🎯</span> Missions</button>
        <button class="nav-item" data-page="ctf"><span class="icon">🏴</span> CTF</button>
        <button class="nav-item" data-page="cheatsheet"><span class="icon">📖</span> Cheatsheet</button>
      </div>
      <div class="nav-section">
        <div class="nav-section-title">Perso</div>
        <button class="nav-item" data-page="favorites"><span class="icon">⭐</span> Favoris</button>
        <button class="nav-item" data-page="notes"><span class="icon">📝</span> Notes</button>
        <button class="nav-item" data-page="progress"><span class="icon">📊</span> Progression</button>
      </div>
      <div class="nav-section">
        <div class="nav-section-title">Système</div>
        <button class="nav-item" data-page="ethics"><span class="icon">⚠️</span> Cyber Ethics</button>
        <button class="nav-item" data-page="export-gate"><span class="icon">📦</span> Export</button>
        <button class="nav-item" data-page="settings"><span class="icon">⚙️</span> Paramètres</button>
      </div>
    `;
    nav.querySelectorAll("[data-page]").forEach(btn => {
      btn.addEventListener("click", () => {
        const page = btn.dataset.page;
        if (page === "export-gate") {
          document.getElementById("export-password").value = "";
          document.getElementById("export-modal").classList.add("show");
        } else {
          this.navigate(page);
        }
        document.getElementById("sidebar").classList.remove("open");
      });
    });
  },

  setActiveNav(page) {
    document.querySelectorAll(".nav-item").forEach(n => n.classList.remove("active"));
    const btn = document.querySelector(`[data-page="${page}"]`) || document.querySelector(`[data-page="${page.split(":")[0]}"]`);
    btn?.classList.add("active");
  },

  setBreadcrumb(parts) {
    const el = document.getElementById("breadcrumb");
    el.innerHTML = parts.map((p, i) =>
      i === parts.length - 1
        ? `<span class="current">${p}</span>`
        : `<span>${p}</span><span>›</span>`
    ).join("");
  },

  navigate(page, params = {}) {
    this.currentPage = page;
    this.setActiveNav(page);
    const content = document.getElementById("content");
    content.innerHTML = "";
    content.className = "content page";

    const routes = {
      dashboard: () => this.pageDashboard(),
      courses: () => this.pageCourses(),
      module: () => this.pageModule(params.id),
      lesson: () => this.pageLesson(params.moduleId, params.courseId),
      commands: () => this.pageCommands(),
      command: () => this.pageCommand(params.id),
      terminal: () => this.pageTerminal(params.cmd),
      labs: () => this.pageLabs(),
      lab: () => this.pageLab(params.id),
      missions: () => this.pageMissions(),
      ctf: () => this.pageCTF(),
      cheatsheet: () => this.pageCheatsheet(),
      favorites: () => this.pageFavorites(),
      notes: () => this.pageNotes(),
      progress: () => this.pageProgress(),
      ethics: () => this.pageEthics(),
      export: () => this.pageExport(),
      settings: () => this.pageSettings(),
      search: () => this.pageSearch(),
      quiz: () => this.pageQuiz(params.id)
    };

    const fn = routes[page] || routes.dashboard;
    fn.call(this);
    this.updateHeaderStats();
  },

  // ─── PAGES ─────────────────────────────────────────────
  pageDashboard() {
    this.setBreadcrumb(["Dashboard"]);
    const p = this.progress;
    const totalCourses = MODULES.reduce((s, m) => s + m.courses.length, 0);
    const doneCourses = p.completedCourses.length;
    const pct = totalCourses ? Math.round((doneCourses / totalCourses) * 100) : 0;
    const levelInfo = LEVELS.find(l => l.id === p.level) || LEVELS[0];

    let continueHtml = "";
    if (p.lastCourse) {
      let found = null, mod = null;
      for (const m of MODULES) {
        const c = m.courses.find(x => x.id === p.lastCourse);
        if (c) { found = c; mod = m; break; }
      }
      if (found) {
        continueHtml = `
          <div class="continue-card mt-3">
            <div class="info">
              <h3>Continuer</h3>
              <p>${mod.title} — ${found.title}</p>
              <div class="progress-bar" style="width:200px"><div class="progress-fill" style="width:${pct}%"></div></div>
            </div>
            <button class="btn btn-primary" onclick="App.navigate('lesson',{moduleId:'${mod.id}',courseId:'${found.id}'})">Continuer →</button>
          </div>`;
      }
    }

    document.getElementById("content").innerHTML = `
      <div class="mb-3">
        <h1>CYBER LAB</h1>
        <p class="text-secondary" style="font-size:1.1rem">Apprends. Expérimente. Comprends.</p>
      </div>
      <div class="grid grid-4 mb-3">
        <div class="stat-card"><div class="label">XP</div><div class="value xp">${p.xp}</div></div>
        <div class="stat-card"><div class="label">Niveau</div><div class="value accent">${levelInfo.icon} ${levelInfo.name}</div><div class="sub">${levelInfo.desc}</div></div>
        <div class="stat-card"><div class="label">Cours</div><div class="value cyan">${doneCourses} / ${totalCourses}</div>
          <div class="progress-bar"><div class="progress-fill" style="width:${pct}%"></div></div></div>
        <div class="stat-card"><div class="label">Labs</div><div class="value">${p.completedLabs.length} / ${LABS.length}</div></div>
      </div>
      <div class="grid grid-3 mb-3">
        <div class="stat-card"><div class="label">Quiz réussis</div><div class="value">${Object.keys(p.quizScores).length}</div></div>
        <div class="stat-card"><div class="label">Missions</div><div class="value">${p.completedMissions.length} / ${MISSIONS.length}</div></div>
        <div class="stat-card"><div class="label">Badges</div><div class="value">${p.badges.length}</div></div>
      </div>
      ${continueHtml}
      <h2 class="mt-3 mb-2">Modules</h2>
      <div class="module-list">
        ${MODULES.map(m => {
          const done = m.courses.filter(c => p.completedCourses.includes(c.id)).length;
          const mp = m.courses.length ? Math.round(done / m.courses.length * 100) : 0;
          return `<div class="module-item" onclick="App.navigate('module',{id:'${m.id}'})">
            <div class="num">${m.num}</div>
            <div class="info"><div class="name">${m.icon} ${m.title}</div><div class="count">${m.courses.length} cours · Niveau ${m.level}</div></div>
            <div class="progress-mini"><div class="fill" style="width:${mp}%"></div></div>
          </div>`;
        }).join("")}
      </div>
    `;
  },

  pageCourses() {
    this.setBreadcrumb(["Cours"]);
    document.getElementById("content").innerHTML = `
      <h1 class="mb-2">📚 Tous les modules</h1>
      <p class="text-secondary mb-3">Progression pédagogique de l'initiation à l'expertise.</p>
      <div class="module-list">
        ${MODULES.map(m => `
          <div class="module-item" onclick="App.navigate('module',{id:'${m.id}'})">
            <div class="num">${m.num}</div>
            <div class="info">
              <div class="name">${m.icon} ${m.title}</div>
              <div class="count">${m.description}</div>
            </div>
            <span class="badge badge-${['green','blue','purple','orange','red','gray'][m.level-1] || 'gray'}">N${m.level}</span>
          </div>`).join("")}
      </div>
    `;
  },

  pageModule(id) {
    const mod = MODULES.find(m => m.id === id);
    if (!mod) return this.navigate("courses");
    this.setBreadcrumb(["Cours", mod.title]);
    const p = this.progress;
    const quiz = QUIZZES[id];
    document.getElementById("content").innerHTML = `
      <div class="flex-between mb-3">
        <div>
          <h1>${mod.icon} ${mod.title}</h1>
          <p class="text-secondary">${mod.description}</p>
        </div>
        ${quiz ? `<button class="btn btn-secondary" onclick="App.navigate('quiz',{id:'${id}'})">📝 Quiz</button>` : ""}
      </div>
      <div class="module-list">
        ${mod.courses.map((c, i) => {
          const done = p.completedCourses.includes(c.id);
          return `<div class="module-item" onclick="App.navigate('lesson',{moduleId:'${mod.id}',courseId:'${c.id}'})">
            <div class="num">${String(i+1).padStart(2,"0")}</div>
            <div class="info">
              <div class="name">${done ? "✅ " : ""}${c.title}</div>
              <div class="count">${c.duration} · +${c.xp} XP</div>
            </div>
          </div>`;
        }).join("")}
      </div>
    `;
  },

  pageLesson(moduleId, courseId) {
    const mod = MODULES.find(m => m.id === moduleId);
    const course = mod?.courses.find(c => c.id === courseId);
    const content = getLessonContent(moduleId, courseId);
    if (!mod || !course || !content) return this.navigate("courses");
    this.setBreadcrumb(["Cours", mod.title, course.title]);
    const p = this.progress;
    const isDone = p.completedCourses.includes(courseId);
    const note = p.notes[courseId] || "";

    document.getElementById("content").innerHTML = `
      <div class="flex-between mb-2">
        <h1>${content.title}</h1>
        <div class="flex gap-1">
          <button class="btn btn-ghost btn-sm" onclick="App.toggleFav('courses','${courseId}')">⭐</button>
          ${isDone ? '<span class="badge badge-green">Terminé</span>' : `<button class="btn btn-primary btn-sm" onclick="App.markCourseDone('${courseId}')">Marquer terminé (+10 XP)</button>`}
        </div>
      </div>
      ${content.sections.map(s => `
        <div class="card mb-2">
          <h3 class="mb-1">${s.title}</h3>
          <div class="text-secondary">${s.html}</div>
        </div>
      `).join("")}
      ${content.exercise ? `
        <div class="exercise-box">
          <h4>🧪 EXERCICE — ${content.exercise.objective}</h4>
          <p><strong>📋 Consigne :</strong> ${content.exercise.steps}</p>
          <button class="btn btn-secondary btn-sm mt-1" onclick="this.nextElementSibling.classList.toggle('show')">💡 Afficher la solution</button>
          <div class="solution-box"><strong>🔓 Solution :</strong> <pre>${content.exercise.solution}</pre></div>
        </div>
      ` : ""}
      <div class="card mt-2">
        <h3>📝 Mes notes</h3>
        <textarea id="lesson-note" class="w-full" rows="4" style="background:var(--bg-input);border:1px solid var(--border);border-radius:6px;color:var(--text-primary);padding:0.75rem;font-family:inherit;margin-top:0.5rem">${note}</textarea>
        <button class="btn btn-secondary btn-sm mt-1" onclick="App.saveLessonNote('${courseId}')">Sauvegarder</button>
      </div>
      <div class="card mt-2">
        <h3>📌 Résumé</h3>
        <p class="text-secondary">${content.summary}</p>
      </div>
      <div class="flex gap-2 mt-3">
        <button class="btn btn-secondary" onclick="App.navigate('module',{id:'${moduleId}'})">← Retour au module</button>
      </div>
    `;
  },

  markCourseDone(id) {
    completeCourse(id);
    this.progress = loadProgress();
    this.updateHeaderStats();
    showToast("Cours terminé ! +10 XP", "xp");
    // re-render current
    const parts = this.currentPage;
  },

  saveLessonNote(id) {
    const text = document.getElementById("lesson-note")?.value || "";
    saveNote(id, text);
    showToast("Note sauvegardée");
  },

  toggleFav(type, id) {
    toggleFavorite(type, id);
    showToast("Favoris mis à jour");
  },

  pageCommands() {
    this.setBreadcrumb(["Commandes"]);
    const cats = [...new Set(COMMANDS.map(c => c.category))];
    document.getElementById("content").innerHTML = `
      <h1 class="mb-2">⌨️ Commandes</h1>
      <p class="text-secondary mb-2">Fiches pédagogiques complètes — regroupées par objectif.</p>
      <input type="search" id="cmd-search" placeholder="Rechercher une commande..." style="width:100%;max-width:400px;background:var(--bg-input);border:1px solid var(--border);border-radius:999px;padding:0.6rem 1rem;color:var(--text-primary);margin-bottom:1rem" />
      <div class="tabs" id="cmd-tabs">
        <button class="tab active" data-cat="all">Toutes</button>
        ${cats.map(c => `<button class="tab" data-cat="${c}">${c}</button>`).join("")}
      </div>
      <div class="grid grid-2" id="cmd-list">
        ${COMMANDS.map(c => this._cmdCard(c)).join("")}
      </div>
    `;
    document.getElementById("cmd-search").addEventListener("input", (e) => {
      const q = e.target.value.toLowerCase();
      document.getElementById("cmd-list").innerHTML = COMMANDS
        .filter(c => !q || c.name.includes(q) || c.summary.toLowerCase().includes(q) || c.tags.some(t => t.includes(q)))
        .map(c => this._cmdCard(c)).join("");
    });
    document.querySelectorAll("#cmd-tabs .tab").forEach(tab => {
      tab.addEventListener("click", () => {
        document.querySelectorAll("#cmd-tabs .tab").forEach(t => t.classList.remove("active"));
        tab.classList.add("active");
        const cat = tab.dataset.cat;
        document.getElementById("cmd-list").innerHTML = COMMANDS
          .filter(c => cat === "all" || c.category === cat)
          .map(c => this._cmdCard(c)).join("");
      });
    });
  },

  _cmdCard(c) {
    return `<div class="course-card" onclick="App.navigate('command',{id:'${c.id}'})">
      <div class="top"><span class="title font-mono">${c.name}</span><span class="badge badge-gray">N${c.level}</span></div>
      <div class="desc">${c.summary}</div>
      <div class="meta"><span>${c.category}</span></div>
    </div>`;
  },

  pageCommand(id) {
    const c = COMMANDS_BY_ID[id];
    if (!c) return this.navigate("commands");
    this.setBreadcrumb(["Commandes", c.name]);
    document.getElementById("content").innerHTML = `
      <div class="command-fiche">
        <div class="command-fiche-header">
          <h2>${c.name}</h2>
          <div class="command-meta">
            <span class="badge badge-cyan">${c.category}</span>
            <span class="badge badge-blue">Niveau ${c.level}</span>
            ${c.os.map(o => `<span class="badge badge-gray">${o}</span>`).join("")}
          </div>
        </div>
        <div class="command-body">
          <div class="command-section"><h3>🎯 À quoi ça sert ?</h3><p>${c.description}</p></div>
          <div class="command-section"><h3>📐 Syntaxe</h3><pre>${c.syntax}</pre></div>
          ${c.options.length ? `<div class="command-section"><h3>⚙️ Options</h3>
            <ul>${c.options.map(o => `<li><code>${o.flag}</code> — ${o.desc}</li>`).join("")}</ul></div>` : ""}
          <div class="command-section"><h3>💡 Exemples</h3>
            ${c.examples.map(ex => `<div class="example-box"><code>${ex.cmd}</code><div class="text-xs text-muted mt-1">${ex.note}</div>
              <button class="btn btn-ghost btn-sm copy-btn" onclick="navigator.clipboard.writeText('${ex.cmd.replace(/'/g,"\\'")}')">Copier</button></div>`).join("")}
          </div>
          <div class="command-section"><h3>👀 Ce que tu vas observer</h3><p>${c.observe}</p></div>
          <div class="command-section"><h3>📌 Cas d'utilisation</h3><ul>${c.useCases.map(u => `<li>${u}</li>`).join("")}</ul></div>
          ${c.errors.length ? `<div class="command-section"><h3>⚠️ Erreurs courantes</h3><ul>${c.errors.map(e => `<li>${e}</li>`).join("")}</ul></div>` : ""}
          <div class="command-section"><h3>🔗 Commandes associées</h3><p>${c.related.map(r => `<a href="#" onclick="App.navigate('command',{id:'${r}'});return false">${r}</a>`).join(" · ")}</p></div>
          <div class="command-section"><h3>🛡️ Utilité en cybersécurité</h3><p>${c.cyber}</p></div>
          ${c.exercise ? `<div class="exercise-box"><h4>🧪 Exercice</h4><p>${c.exercise.objective}</p>
            <button class="btn btn-secondary btn-sm" onclick="this.nextElementSibling.classList.toggle('show')">Solution</button>
            <div class="solution-box"><pre>${c.exercise.solution}</pre></div></div>` : ""}
          <div class="mt-3">
            <button class="btn btn-primary" onclick="App.navigate('terminal',{cmd:'${c.name}'})">▶ Tester dans le terminal</button>
            <button class="btn btn-ghost" onclick="App.toggleFav('commands','${c.id}')">⭐ Favoris</button>
          </div>
        </div>
      </div>
    `;
  },

  pageTerminal(preCmd) {
    this.setBreadcrumb(["Terminal Lab"]);
    document.getElementById("content").innerHTML = `
      <h1 class="mb-1">💻 Terminal Lab</h1>
      <p class="text-secondary mb-2">Simulation locale — aucune commande n'est exécutée sur votre système réel.</p>
      <div id="terminal-root"></div>
      <div class="card mt-2">
        <h4>Commandes disponibles</h4>
        <p class="text-sm text-secondary">help, dir, cd, type, echo, whoami, hostname, ipconfig, ping, nslookup, netstat, arp, tree, tasklist, cls...</p>
      </div>
    `;
    this.terminal = new SimulatedTerminal(document.getElementById("terminal-root"));
    this.terminal.render();
    if (preCmd) {
      setTimeout(() => this.terminal.runCommand(preCmd), 100);
    }
    const p = loadProgress();
    if (!p.badges.includes("first-command")) {
      p.badges.push("first-command");
      saveProgress(p);
    }
  },

  pageLabs() {
    this.setBreadcrumb(["Labs"]);
    document.getElementById("content").innerHTML = `
      <h1 class="mb-2">🧪 Labs</h1>
      <p class="text-secondary mb-3">Environnements contrôlés et données fictives uniquement.</p>
      <div class="grid grid-2">
        ${LABS.map(l => {
          const done = this.progress.completedLabs.includes(l.id);
          return `<div class="course-card" onclick="App.navigate('lab',{id:'${l.id}'})">
            <div class="top"><span class="title">${l.icon} ${l.title}</span>${done ? '<span class="badge badge-green">Fait</span>' : `<span class="badge badge-orange">+${l.xp} XP</span>`}</div>
            <div class="desc">${l.description}</div>
            <div class="meta">Niveau ${l.level}</div>
          </div>`;
        }).join("")}
      </div>
    `;
  },

  pageLab(id) {
    const lab = LABS.find(l => l.id === id);
    if (!lab) return this.navigate("labs");
    this.setBreadcrumb(["Labs", lab.title]);

    if (id === "fake-stealer") {
      document.getElementById("content").innerHTML = this._labFakeStealer(lab);
      return;
    }
    if (id === "http-inspector") {
      document.getElementById("content").innerHTML = this._labHttp(lab);
      return;
    }
    if (id === "ai-classify") {
      document.getElementById("content").innerHTML = this._labAI(lab);
      return;
    }
    // generic
    document.getElementById("content").innerHTML = `
      <h1>${lab.icon} ${lab.title}</h1>
      <p class="text-secondary mb-2">${lab.description}</p>
      <div class="card">
        <p>Ce lab utilise uniquement des données et scénarios fictifs dans un environnement contrôlé.</p>
        <p class="mt-2">Utilisez le <strong>Terminal Lab</strong> et les cours associés pour progresser.</p>
        <button class="btn btn-primary mt-2" onclick="App.completeLabNow('${lab.id}')">Marquer lab terminé (+50 XP)</button>
      </div>
    `;
  },

  _labFakeStealer(lab) {
    return `
      <h1>🦠 FAKE STEALER Lab</h1>
      <p class="text-secondary mb-2">Simulation 100 % inoffensive — aucune donnée réelle n'est lue ni exfiltrée.</p>
      <div class="card mb-2" style="border-color:var(--accent-orange)">
        <h3>⚠️ Rappel éthique</h3>
        <p>Ce lab enseigne les <em>concepts</em> derrière un stealer. Les seules données manipulées sont :</p>
        <pre>FAKE_WIFI_NAME=CyberLab_Test
FAKE_WIFI_PASSWORD=NotARealPassword123
FAKE_USERNAME=student
FAKE_PC=LAB-PC
FAKE_TOKEN=fake-token-0000-demo</pre>
      </div>
      <div class="card mb-2">
        <h3>1. Lancer la simulation</h3>
        <p class="text-secondary mb-1">Le « programme » lit les variables fictives, construit un JSON, et simule un POST vers un endpoint de lab.</p>
        <button class="btn btn-primary" onclick="App.runFakeStealer()">▶ Exécuter la simulation</button>
        <pre id="fake-output" class="mt-2" style="display:none"></pre>
      </div>
      <div class="card mb-2">
        <h3>2. IOC côté défenseur</h3>
        <ul class="text-secondary">
          <li>Fichier <code>fake_report.json</code> créé dans un dossier Labs</li>
          <li>Processus script inhabituel</li>
          <li>Connexion HTTP POST vers un endpoint non légitime</li>
          <li>Chaînes caractéristiques dans le binaire/script</li>
        </ul>
      </div>
      <button class="btn btn-secondary" onclick="App.completeLabNow('fake-stealer')">Marquer lab terminé (+50 XP)</button>
    `;
  },

  _labHttp(lab) {
    return `
      <h1>🌍 HTTP Request Inspector</h1>
      <p class="text-secondary mb-2">Requête HTTP fictive complète pour l'apprentissage.</p>
      <div class="grid grid-2">
        <div class="card">
          <h3>REQUEST</h3>
          <p><strong>METHOD</strong> GET</p>
          <p><strong>URL</strong> https://lab.cyber.local/api/users/42</p>
          <p><strong>HEADERS</strong></p>
          <pre>Host: lab.cyber.local
User-Agent: CYBERLAB-Browser/1.0
Accept: application/json
Cookie: session=fake-session-abc123</pre>
          <p><strong>BODY</strong> (vide pour GET)</p>
        </div>
        <div class="card">
          <h3>RESPONSE</h3>
          <p><strong>STATUS</strong> 200 OK</p>
          <p><strong>HEADERS</strong></p>
          <pre>Content-Type: application/json
Set-Cookie: session=fake-session-abc123; HttpOnly
Cache-Control: no-store</pre>
          <p><strong>BODY</strong></p>
          <pre>{"id":42,"name":"Student Lab","role":"learner"}</pre>
        </div>
      </div>
      <button class="btn btn-primary mt-2" onclick="App.completeLabNow('http-inspector')">Marquer lab terminé (+50 XP)</button>
    `;
  },

  _labAI(lab) {
    const events = [
      { type: "LOGIN", detail: "user=student from=192.168.1.42 success=true", label: "NORMAL" },
      { type: "LOGIN", detail: "user=admin from=185.22.99.1 success=false attempts=12", label: "SUSPICIOUS" },
      { type: "FILE_ACCESS", detail: "path=C:\\Users\\student\\notes.txt action=read", label: "NORMAL" },
      { type: "FILE_ACCESS", detail: "path=C:\\Windows\\System32\\config\\SAM action=read", label: "SUSPICIOUS" },
      { type: "NETWORK_CONNECTION", detail: "dst=8.8.8.8:53 proto=UDP", label: "NORMAL" },
      { type: "NETWORK_CONNECTION", detail: "dst=91.200.12.45:4444 proto=TCP", label: "SUSPICIOUS" },
      { type: "PROCESS_START", detail: "image=notepad.exe parent=explorer.exe", label: "NORMAL" },
      { type: "PROCESS_START", detail: "image=powershell.exe args=-enc <base64> parent=winword.exe", label: "SUSPICIOUS" },
      { type: "DNS_REQUEST", detail: "query=update.microsoft.com", label: "NORMAL" },
      { type: "DNS_REQUEST", detail: "query=c2-malware-evil.xyz", label: "SUSPICIOUS" }
    ];
    return `
      <h1>🤖 Classification d'événements</h1>
      <p class="text-secondary mb-2">Classez chaque événement fictif en NORMAL ou SUSPICIOUS. (Jeu de données 100 % synthétique)</p>
      <div id="ai-events">
        ${events.map((e, i) => `
          <div class="card mb-1" id="ev-${i}">
            <strong>${e.type}</strong>
            <div class="text-sm text-secondary font-mono">${e.detail}</div>
            <div class="flex gap-1 mt-1">
              <button class="btn btn-sm btn-secondary" onclick="App.classifyEvent(${i},'NORMAL','${e.label}')">NORMAL</button>
              <button class="btn btn-sm btn-secondary" onclick="App.classifyEvent(${i},'SUSPICIOUS','${e.label}')">SUSPICIOUS</button>
              <span id="ev-result-${i}"></span>
            </div>
          </div>`).join("")}
      </div>
      <button class="btn btn-primary mt-2" onclick="App.completeLabNow('ai-classify')">Marquer lab terminé (+50 XP)</button>
    `;
  },

  classifyEvent(i, choice, correct) {
    const el = document.getElementById("ev-result-" + i);
    if (choice === correct) {
      el.innerHTML = '<span class="badge badge-green">Correct</span>';
    } else {
      el.innerHTML = '<span class="badge badge-red">Incorrect — attendu : ' + correct + '</span>';
    }
  },

  runFakeStealer() {
    const out = document.getElementById("fake-output");
    if (!out) return;
    out.style.display = "block";
    out.textContent = `[SIMULATION] Lecture des variables fictives...
[SIMULATION] Construction du rapport...
{
  "fake_username": "student",
  "fake_pc": "LAB-PC",
  "fake_wifi_name": "CyberLab_Test",
  "fake_wifi_password": "NotARealPassword123",
  "fake_token": "fake-token-0000-demo",
  "timestamp": "${new Date().toISOString()}",
  "note": "DONNÉES FICTIVES — AUCUNE DONNÉE RÉELLE"
}
[SIMULATION] POST http://lab-server.local/api/exfil (mock)
[SIMULATION] Réponse : 200 OK (serveur de lab fictif)
[SIMULATION] Terminé. Aucune donnée réelle n'a quitté cette machine.`;
  },

    completeLabNow(id) {
    completeLab(id);
    this.progress = loadProgress();
    this.updateHeaderStats();
    showToast("Lab terminé ! +50 XP", "xp");
  },

  pageMissions() {
    this.setBreadcrumb(["Missions"]);
    document.getElementById("content").innerHTML = `
      <h1 class="mb-2">🎯 Missions</h1>
      <p class="text-secondary mb-3">Scénarios multi-compétences. Environnements fictifs uniquement.</p>
      <div class="grid grid-2">
        ${MISSIONS.map(m => {
          const done = this.progress.completedMissions.includes(m.id);
          return `<div class="card">
            <div class="flex-between"><h3>${m.icon} ${m.title}</h3>${done ? '<span class="badge badge-green">Terminée</span>' : `<span class="badge badge-orange">+${m.xp} XP</span>`}</div>
            <p class="text-secondary text-sm mt-1">${m.description}</p>
            <ul class="text-sm mt-1">${m.objectives.map(o => `<li>${o}</li>`).join("")}</ul>
            ${!done ? `<button class="btn btn-primary btn-sm mt-2" onclick="App.completeMissionNow('${m.id}')">Marquer terminée</button>` : ""}
          </div>`;
        }).join("")}
      </div>
    `;
  },

  completeMissionNow(id) {
    completeMission(id);
    this.progress = loadProgress();
    this.updateHeaderStats();
    showToast("Mission terminée ! +100 XP", "xp");
    this.navigate("missions");
  },

  pageCTF() {
    this.setBreadcrumb(["CTF"]);
    document.getElementById("content").innerHTML = `
      <h1 class="mb-2">🏴 CTF — Challenges fictifs</h1>
      <p class="text-secondary mb-3">Aucune cible Internet réelle. Flags dans le terminal de simulation.</p>
      ${CTFS.map(c => `
        <div class="card mb-2">
          <div class="flex-between">
            <h3>TARGET: ${c.title}</h3>
            <span class="badge badge-green">${c.status}</span>
          </div>
          <p class="text-secondary">${c.description}</p>
          <p class="text-sm">Difficulté : ${c.difficulty} · +${c.xp} XP</p>
          <input type="text" id="flag-${c.id}" placeholder="CYBERLAB{...}" style="background:var(--bg-input);border:1px solid var(--border);border-radius:6px;padding:0.5rem;color:var(--text-primary);width:100%;max-width:360px;margin-top:0.5rem" />
          <button class="btn btn-primary btn-sm mt-1" onclick="App.submitFlag('${c.id}','${c.flag}')">Soumettre</button>
        </div>
      `).join("")}
      <p class="text-sm text-muted mt-2">Indice CTF1 : explorez C:\\Labs\\CTF dans le Terminal Lab.</p>
    `;
  },

  submitFlag(id, correct) {
    const val = document.getElementById("flag-" + id)?.value.trim();
    if (val === correct) {
      const p = loadProgress();
      if (!p.completedCTFs.includes(id)) {
        p.completedCTFs.push(id);
        saveProgress(p);
        addXP(150, "CTF résolu");
      }
      showToast("Flag correct ! +150 XP", "xp");
    } else {
      showToast("Flag incorrect", "error");
    }
  },

  pageCheatsheet() {
    this.setBreadcrumb(["Cheatsheet"]);
    const groups = {};
    COMMANDS.forEach(c => {
      if (!groups[c.category]) groups[c.category] = [];
      groups[c.category].push(c);
    });
    document.getElementById("content").innerHTML = `
      <h1 class="mb-2">📖 Command Cheatsheet</h1>
      <input type="search" id="cheat-search" placeholder="Filtrer..." style="width:100%;max-width:320px;background:var(--bg-input);border:1px solid var(--border);border-radius:999px;padding:0.5rem 1rem;color:var(--text-primary);margin-bottom:1rem" />
      <div id="cheat-body">
        ${Object.entries(groups).map(([cat, cmds]) => `
          <div class="mb-3">
            <h3 class="mb-1">${cat.toUpperCase()}</h3>
            <div class="flex gap-1" style="flex-wrap:wrap">
              ${cmds.map(c => `<button class="btn btn-secondary btn-sm font-mono" onclick="App.navigate('command',{id:'${c.id}'})">${c.name}</button>`).join("")}
            </div>
          </div>
        `).join("")}
      </div>
    `;
  },

  pageFavorites() {
    this.setBreadcrumb(["Favoris"]);
    const p = this.progress;
    document.getElementById("content").innerHTML = `
      <h1 class="mb-2">⭐ Favoris</h1>
      <h3>Commandes</h3>
      <div class="flex gap-1 mb-2" style="flex-wrap:wrap">
        ${(p.favorites.commands || []).map(id => {
          const c = COMMANDS_BY_ID[id];
          return c ? `<button class="btn btn-secondary btn-sm" onclick="App.navigate('command',{id:'${id}'})">${c.name}</button>` : "";
        }).join("") || '<span class="text-muted">Aucun</span>'}
      </div>
      <h3>Cours</h3>
      <div class="text-secondary">${(p.favorites.courses || []).length ? p.favorites.courses.join(", ") : "Aucun"}</div>
    `;
  },

  pageNotes() {
    this.setBreadcrumb(["Notes"]);
    const notes = this.progress.notes || {};
    const keys = Object.keys(notes);
    document.getElementById("content").innerHTML = `
      <h1 class="mb-2">📝 Notes personnelles</h1>
      ${keys.length === 0 ? '<p class="text-muted">Aucune note pour le moment. Ajoutez-en depuis un cours.</p>' :
        keys.map(k => `<div class="card mb-2"><h4>${k}</h4><pre style="white-space:pre-wrap">${notes[k]}</pre></div>`).join("")}
    `;
  },

  pageProgress() {
    this.setBreadcrumb(["Progression"]);
    const p = this.progress;
    document.getElementById("content").innerHTML = `
      <h1 class="mb-2">📊 Progression</h1>
      <div class="grid grid-3 mb-3">
        <div class="stat-card"><div class="label">XP total</div><div class="value xp">${p.xp}</div></div>
        <div class="stat-card"><div class="label">Niveau</div><div class="value">${p.level}</div></div>
        <div class="stat-card"><div class="label">Badges</div><div class="value">${p.badges.length}</div></div>
      </div>
      <h3>Badges obtenus</h3>
      <div class="flex gap-1 mb-3" style="flex-wrap:wrap">
        ${BADGES.filter(b => p.badges.includes(b.id)).map(b => `
          <div class="stat-pill" title="${b.desc}">${b.icon} ${b.name}</div>
        `).join("") || '<span class="text-muted">Aucun badge encore</span>'}
      </div>
      <h3>Quiz</h3>
      <ul class="text-secondary">
        ${Object.entries(p.quizScores).map(([id, s]) => `<li>${id} : ${s.score}/${s.total}</li>`).join("") || "<li>Aucun quiz passé</li>"}
      </ul>
      <button class="btn btn-secondary mt-3" onclick="if(confirm('Réinitialiser toute la progression ?')){resetProgress();App.progress=loadProgress();App.navigate('progress');App.updateHeaderStats()}">Réinitialiser ma progression</button>
    `;
  },

  pageEthics() {
    this.setBreadcrumb(["Cyber Ethics"]);
    document.getElementById("content").innerHTML = `
      <h1 class="mb-2">⚠️ Cyber Ethics</h1>
      <div class="card mb-2">
        <h3>Autorisation et scope</h3>
        <p class="text-secondary">Toute activité de test de sécurité doit être explicitement autorisée. Le scope définit ce qui est permis et ce qui est interdit. Sortir du scope est illégal.</p>
      </div>
      <div class="card mb-2">
        <h3>Données personnelles</h3>
        <p class="text-secondary">Ne collectez jamais d'informations privées sur des particuliers sans base légale. L'OSINT reste sur des sources publiques et des cibles organisationnelles ou fictives.</p>
      </div>
      <div class="card mb-2">
        <h3>Responsible disclosure</h3>
        <p class="text-secondary">Si vous découvrez une vulnérabilité réelle, signalez-la de façon responsable au propriétaire — ne l'exploitez pas et ne la publiez pas sans coordination.</p>
      </div>
      <div class="card mb-2">
        <h3>Apprentissage ≠ attaque</h3>
        <p class="text-secondary">CYBER LAB utilise exclusivement des simulations, des données fictives et des environnements contrôlés. L'objectif est de comprendre pour mieux défendre, pas de nuire.</p>
      </div>
      <div class="card">
        <h3>Pourquoi un lab est important</h3>
        <p class="text-secondary">S'entraîner sur des machines volontairement vulnérables ou des scénarios fictifs permet d'acquérir des compétences sans risquer de systèmes de production ni enfreindre la loi.</p>
      </div>
    `;
  },

  pageExport() {
    this.setBreadcrumb(["Export"]);
    document.getElementById("content").innerHTML = `
      <h1 class="mb-2">📦 Export du site</h1>
      <p class="text-secondary mb-2">Prototype — le code d'accès (8808) n'est pas une protection cryptographique réelle. Il est visible dans le code source.</p>
      <div class="grid grid-2">
        <div class="card">
          <h3>Télécharger le projet</h3>
          <p class="text-sm text-secondary mb-2">Génère une archive ZIP avec HTML, CSS, JS et données pour un fonctionnement local.</p>
          <button class="btn btn-primary" onclick="App.downloadZip()">Télécharger le site complet (ZIP)</button>
        </div>
        <div class="card">
          <h3>Progression</h3>
          <button class="btn btn-secondary mb-1" onclick="App.downloadProgress()">Exporter ma progression (JSON)</button>
          <br>
          <label class="text-sm">Importer une progression :</label>
          <input type="file" id="import-prog" accept=".json" class="mt-1" />
        </div>
      </div>
      <div class="card mt-2">
        <h3>Structure exportée</h3>
        <pre>CYBER-LAB/
├── index.html
├── css/styles.css
├── js/app.js, data/, utils/
├── manifest.json
└── README.md</pre>
      </div>
    `;
    document.getElementById("import-prog")?.addEventListener("change", async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const text = await file.text();
      if (importProgress(text)) {
        showToast("Progression importée");
        App.progress = loadProgress();
        App.updateHeaderStats();
      } else showToast("Fichier invalide", "error");
    });
  },

  async downloadZip() {
    if (typeof JSZip === "undefined") {
      showToast("JSZip non chargé", "error");
      return;
    }
    showToast("Génération du ZIP...");
    const zip = new JSZip();
    // We package the known structure; for a full offline export the user already has the files.
    // Here we export a minimal bootstrap + progress + README.
    const readme = `# CYBER LAB

Plateforme éducative de cybersécurité — prototype local.

## Lancement
Ouvrir index.html dans un navigateur moderne (Chrome, Firefox, Edge).
Ou servir le dossier avec un serveur local :
  npx serve .
  python -m http.server 8080

## Fonctionnalités
- Cours progressifs, fiches commandes, terminal simulé
- Labs (FAKE STEALER 100% inoffensif), missions, CTF fictifs
- Quiz, XP, badges, notes, favoris (localStorage)
- Export / import de progression

## Sécurité
Le code d'accès export (8808) est un simple masquage UI, pas une protection réelle.
Aucune donnée n'est envoyée à un serveur distant.
Les labs n'utilisent que des données fictives.

## Éthique
Voir la page Cyber Ethics dans l'application.
`;
    zip.file("README.md", readme);
    zip.file("PROGRESS_EXPORT.json", exportProgress());
    zip.file("manifest.json", JSON.stringify({
      name: "CYBER LAB",
      short_name: "CyberLab",
      start_url: "./index.html",
      display: "standalone",
      background_color: "#0a0e17",
      theme_color: "#00d4aa",
      lang: "fr"
    }, null, 2));

    // Try to fetch local files if served via http
    const files = [
      "index.html", "css/styles.css",
      "js/app.js", "js/data/commands.js", "js/data/courses.js",
      "js/data/quizzes.js", "js/data/labs.js",
      "js/utils/storage.js", "js/utils/terminal.js"
    ];
    for (const f of files) {
      try {
        const res = await fetch(f);
        if (res.ok) zip.file(f, await res.text());
      } catch (e) {
        // offline / file:// — skip
      }
    }

    const blob = await zip.generateAsync({ type: "blob" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "CYBER-LAB-export.zip";
    a.click();
    showToast("ZIP téléchargé");
  },

  downloadProgress() {
    const blob = new Blob([exportProgress()], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "cyberlab-progress.json";
    a.click();
  },

  pageSettings() {
    this.setBreadcrumb(["Paramètres"]);
    document.getElementById("content").innerHTML = `
      <h1 class="mb-2">⚙️ Paramètres</h1>
      <div class="card mb-2">
        <h3>Apparence</h3>
        <p class="text-secondary">Dark mode cyber activé par défaut (seul thème du prototype).</p>
      </div>
      <div class="card mb-2">
        <h3>Données</h3>
        <button class="btn btn-secondary" onclick="if(confirm('Tout effacer ?')){resetProgress();location.reload()}">Réinitialiser la progression</button>
      </div>
      <div class="card">
        <h3>À propos</h3>
        <p class="text-secondary">CYBER LAB v1.0 — Prototype éducatif.<br>Aucune certification professionnelle. Contenu à but pédagogique uniquement.</p>
      </div>
    `;
  },

  pageSearch() {
    this.setBreadcrumb(["Recherche"]);
    const q = this.searchQuery.toLowerCase();
    const cmdHits = COMMANDS.filter(c => c.name.includes(q) || c.summary.toLowerCase().includes(q) || c.tags.some(t => t.includes(q)));
    const courseHits = [];
    MODULES.forEach(m => m.courses.forEach(c => {
      if (c.title.toLowerCase().includes(q) || m.title.toLowerCase().includes(q)) courseHits.push({ ...c, moduleId: m.id, moduleTitle: m.title });
    }));
    document.getElementById("content").innerHTML = `
      <h1 class="mb-2">🔎 Résultats pour « ${this.searchQuery} »</h1>
      <h3>Commandes (${cmdHits.length})</h3>
      <div class="grid grid-2 mb-3">${cmdHits.slice(0, 12).map(c => this._cmdCard(c)).join("") || '<p class="text-muted">Aucune</p>'}</div>
      <h3>Cours (${courseHits.length})</h3>
      <div class="module-list">
        ${courseHits.slice(0, 12).map(c => `
          <div class="module-item" onclick="App.navigate('lesson',{moduleId:'${c.moduleId}',courseId:'${c.id}'})">
            <div class="info"><div class="name">${c.title}</div><div class="count">${c.moduleTitle}</div></div>
          </div>`).join("") || '<p class="text-muted">Aucun</p>'}
      </div>
    `;
  },

  pageQuiz(moduleId) {
    const quiz = QUIZZES[moduleId];
    if (!quiz) return this.navigate("courses");
    this.setBreadcrumb(["Quiz", quiz.title]);
    this._quizState = { quiz, index: 0, answers: {}, score: 0 };
    this._renderQuizQuestion();
  },

  _renderQuizQuestion() {
    const st = this._quizState;
    const q = st.quiz.questions[st.index];
    const total = st.quiz.questions.length;
    let optionsHtml = "";
    if (q.type === "mcq") {
      optionsHtml = q.options.map((o, i) => `
        <button class="quiz-option" data-i="${i}" onclick="App.answerQuiz(${i})">${o}</button>
      `).join("");
    } else if (q.type === "truefalse") {
      optionsHtml = `
        <button class="quiz-option" onclick="App.answerQuiz(true)">Vrai</button>
        <button class="quiz-option" onclick="App.answerQuiz(false)">Faux</button>
      `;
    } else if (q.type === "command") {
      optionsHtml = `
        <input type="text" id="quiz-cmd-input" placeholder="Tapez la commande..." style="width:100%;background:var(--bg-input);border:1px solid var(--border);border-radius:6px;padding:0.75rem;color:var(--text-primary);font-family:var(--font-mono)" />
        <button class="btn btn-primary mt-1" onclick="App.answerQuiz(document.getElementById('quiz-cmd-input').value.trim())">Valider</button>
      `;
    }
    document.getElementById("content").innerHTML = `
      <div class="quiz-container">
        <div class="flex-between mb-2">
          <h1>${st.quiz.title}</h1>
          <span class="badge badge-cyan">${st.index + 1} / ${total}</span>
        </div>
        <div class="quiz-question">
          <h3>${q.question}</h3>
          <div class="quiz-options">${optionsHtml}</div>
          <div id="quiz-explain"></div>
        </div>
      </div>
    `;
  },

  answerQuiz(answer) {
    const st = this._quizState;
    const q = st.quiz.questions[st.index];
    let correct = false;
    if (q.type === "mcq") correct = answer === q.correct;
    else if (q.type === "truefalse") correct = answer === q.correct;
    else if (q.type === "command") correct = String(answer).toLowerCase() === q.answer.toLowerCase();

    if (correct) st.score++;
    st.answers[q.id] = { answer, correct };

    const explain = document.getElementById("quiz-explain");
    explain.innerHTML = `<div class="quiz-explanation"><strong>${correct ? "✅ Correct" : "❌ Incorrect"}</strong><br>${q.explanation}</div>
      <button class="btn btn-primary mt-2" onclick="App.nextQuizQ()">${st.index < st.quiz.questions.length - 1 ? "Question suivante" : "Voir le score"}</button>`;
  },

  nextQuizQ() {
    const st = this._quizState;
    if (st.index < st.quiz.questions.length - 1) {
      st.index++;
      this._renderQuizQuestion();
    } else {
      const total = st.quiz.questions.length;
      saveQuizScore(st.quiz.id, st.score, total);
      this.progress = loadProgress();
      this.updateHeaderStats();
      document.getElementById("content").innerHTML = `
        <div class="quiz-container">
          <h1>Résultat</h1>
          <div class="stat-card mb-2"><div class="value accent">${st.score} / ${total}</div>
            <div class="sub">${Math.round(st.score / total * 100)} %</div></div>
          <p class="text-secondary">${st.score / total >= 0.7 ? "Bravo ! Quiz validé (+20 XP si première fois)." : "Révisez les cours et réessayez."}</p>
          <button class="btn btn-primary" onclick="App.navigate('module',{id:'${st.quiz.moduleId}'})">Retour au module</button>
        </div>
      `;
    }
  }
};

function showToast(msg, type = "info") {
  const t = document.getElementById("toast");
  document.getElementById("toast-msg").textContent = msg;
  document.getElementById("toast-icon").textContent = type === "xp" ? "⚡" : type === "error" ? "❌" : "✨";
  t.className = "toast show" + (type === "xp" ? " xp" : "");
  setTimeout(() => t.classList.remove("show"), 2800);
}

document.addEventListener("DOMContentLoaded", () => App.init());
