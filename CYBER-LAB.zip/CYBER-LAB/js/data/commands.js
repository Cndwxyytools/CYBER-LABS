/**
 * CYBER LAB — Base de commandes CMD / système
 * Chaque commande a une fiche pédagogique complète.
 */
const COMMANDS = [
  // ─── FICHIERS ───────────────────────────────────────────
  {
    id: "dir",
    name: "dir",
    category: "fichiers",
    level: 1,
    os: ["Windows"],
    tags: ["fichiers", "dossiers", "liste"],
    summary: "Liste le contenu d'un répertoire.",
    description: "La commande dir (directory) affiche la liste des fichiers et dossiers présents dans le répertoire courant ou dans un chemin spécifié. C'est l'équivalent Windows de ls sous Linux. Elle fournit des informations utiles : nom, taille, date de modification et attributs.",
    syntax: "dir [chemin] [options]",
    options: [
      { flag: "/w", desc: "Affichage large (colonnes)" },
      { flag: "/p", desc: "Pause après chaque page d'écran" },
      { flag: "/a", desc: "Affiche aussi les fichiers cachés / système" },
      { flag: "/a:h", desc: "Uniquement les fichiers cachés" },
      { flag: "/s", desc: "Recherche récursive dans les sous-dossiers" },
      { flag: "/b", desc: "Format brut (noms uniquement)" },
      { flag: "/o:n", desc: "Tri par nom" },
      { flag: "/o:d", desc: "Tri par date" },
      { flag: "/o:s", desc: "Tri par taille" }
    ],
    examples: [
      { cmd: "dir", note: "Liste le contenu du dossier courant" },
      { cmd: "dir C:\\Windows\\System32", note: "Liste un dossier spécifique" },
      { cmd: "dir /a /s *.log", note: "Recherche récursive de fichiers .log (y compris cachés)" },
      { cmd: "dir /b /o:n", note: "Noms uniquement, triés alphabétiquement" }
    ],
    observe: "Vous verrez le volume, le numéro de série, puis une liste de dossiers (<DIR>) et de fichiers avec taille et date. En fin d'affichage : nombre de fichiers et d'octets utilisés + espace libre.",
    useCases: [
      "Vérifier rapidement ce qui se trouve dans un dossier",
      "Repérer des fichiers suspects ou récemment modifiés",
      "Combiner avec /s pour cartographier une arborescence"
    ],
    errors: [
      "« Fichier introuvable » → le chemin n'existe pas ou est mal orthographié",
      "Permissions insuffisantes sur certains dossiers système"
    ],
    related: ["cd", "tree", "type", "where"],
    cyber: "En analyse forensique ou incident response, dir /a /s permet de repérer des fichiers cachés, des dumps ou des artefacts laissés par un malware. Surveiller les dates de modification est un IOC classique.",
    exercise: {
      objective: "Lister tous les fichiers .exe du dossier System32 de façon brute.",
      steps: "Utilisez dir avec /b et un filtre.",
      solution: "dir C:\\Windows\\System32\\*.exe /b"
    }
  },
  {
    id: "cd",
    name: "cd",
    category: "fichiers",
    level: 1,
    os: ["Windows"],
    tags: ["navigation", "dossiers"],
    summary: "Change le répertoire de travail courant.",
    description: "cd (Change Directory) permet de se déplacer dans l'arborescence des dossiers. C'est la commande de base pour naviguer avant d'exécuter d'autres actions sur des fichiers. Sans argument, elle affiche le chemin courant.",
    syntax: "cd [chemin]\ncd ..\ncd \\",
    options: [
      { flag: "cd ..", desc: "Remonte d'un niveau (dossier parent)" },
      { flag: "cd \\", desc: "Va à la racine du lecteur actuel" },
      { flag: "cd /d D:\\", desc: "Change aussi de lecteur (D:)" }
    ],
    examples: [
      { cmd: "cd", note: "Affiche le chemin actuel" },
      { cmd: "cd Documents", note: "Entre dans le dossier Documents" },
      { cmd: "cd ..", note: "Remonte d'un niveau" },
      { cmd: "cd C:\\Users\\Public", note: "Chemin absolu" },
      { cmd: "cd /d D:\\Labs", note: "Change de lecteur et de dossier" }
    ],
    observe: "Le prompt change pour refléter le nouveau chemin (ex: C:\\Users\\student>).",
    useCases: [
      "Se positionner avant d'utiliser dir, copy, type, etc.",
      "Scripts Batch qui doivent travailler dans un dossier précis"
    ],
    errors: [
      "« Le chemin d'accès spécifié est introuvable » → orthographe ou dossier inexistant",
      "Oublier /d quand on change de lettre de lecteur"
    ],
    related: ["dir", "mkdir", "tree", "pushd"],
    cyber: "Dans un script d'attaque ou de défense, le chemin de travail influence les chemins relatifs. Toujours vérifier le cwd (current working directory) avant d'analyser des artefacts.",
    exercise: {
      objective: "Aller à la racine du disque C: puis afficher le contenu.",
      steps: "cd \\ puis dir",
      solution: "cd \\\ndir"
    }
  },
  {
    id: "mkdir",
    name: "mkdir",
    category: "fichiers",
    level: 1,
    os: ["Windows"],
    tags: ["dossiers", "création"],
    summary: "Crée un ou plusieurs dossiers.",
    description: "mkdir (ou md) crée un nouveau répertoire. Vous pouvez créer plusieurs dossiers en une seule commande et même des chemins imbriqués si le parent existe déjà (ou avec l'option appropriée selon la version).",
    syntax: "mkdir nom_dossier\nmd nom_dossier",
    options: [],
    examples: [
      { cmd: "mkdir Labs", note: "Crée un dossier Labs" },
      { cmd: "mkdir Labs\\CMD Labs\\Network", note: "Crée deux sous-dossiers" },
      { cmd: "mkdir \"Mon Dossier\"", note: "Nom avec espaces → guillemets obligatoires" }
    ],
    observe: "Aucun message de succès par défaut. Vérifiez avec dir.",
    useCases: [
      "Organiser un espace de travail",
      "Scripts d'installation qui préparent une structure de dossiers"
    ],
    errors: [
      "Dossier déjà existant → message d'erreur",
      "Caractères interdits dans le nom (\\ / : * ? \" < > |)"
    ],
    related: ["rmdir", "cd", "dir"],
    cyber: "Un malware peut créer des dossiers cachés pour stocker des payloads. Surveiller la création de dossiers inhabituels dans AppData ou Temp est une bonne pratique de détection.",
    exercise: {
      objective: "Créer un dossier CYBERLAB puis un sous-dossier notes.",
      steps: "mkdir CYBERLAB puis mkdir CYBERLAB\\notes",
      solution: "mkdir CYBERLAB\nmkdir CYBERLAB\\notes"
    }
  },
  {
    id: "rmdir",
    name: "rmdir",
    category: "fichiers",
    level: 1,
    os: ["Windows"],
    tags: ["dossiers", "suppression"],
    summary: "Supprime un dossier vide (ou non vide avec /s).",
    description: "rmdir (ou rd) supprime des répertoires. Par défaut le dossier doit être vide. L'option /s permet de supprimer récursivement tout le contenu — attention, c'est irréversible.",
    syntax: "rmdir [options] dossier\nrd [options] dossier",
    options: [
      { flag: "/s", desc: "Supprime le dossier et tout son contenu (récursif)" },
      { flag: "/q", desc: "Mode silencieux (pas de confirmation)" }
    ],
    examples: [
      { cmd: "rmdir ancien_dossier", note: "Supprime un dossier vide" },
      { cmd: "rmdir /s /q temp_lab", note: "Suppression récursive sans confirmation" }
    ],
    observe: "En mode /s sans /q, une confirmation est demandée.",
    useCases: [
      "Nettoyage de dossiers temporaires",
      "Scripts de maintenance"
    ],
    errors: [
      "« Le répertoire n'est pas vide » → utiliser /s",
      "Permissions insuffisantes"
    ],
    related: ["mkdir", "del", "rd"],
    cyber: "Des scripts malveillants utilisent parfois rmdir /s /q pour effacer des traces. En forensique, l'absence de dossiers attendus peut elle-même être un indicateur.",
    exercise: {
      objective: "Créer puis supprimer un dossier de test vide.",
      steps: "mkdir test_rm && rmdir test_rm",
      solution: "mkdir test_rm\nrmdir test_rm"
    }
  },
  {
    id: "copy",
    name: "copy",
    category: "fichiers",
    level: 1,
    os: ["Windows"],
    tags: ["fichiers", "copie"],
    summary: "Copie un ou plusieurs fichiers.",
    description: "copy duplique des fichiers d'un emplacement vers un autre. Elle ne copie pas les dossiers (utilisez xcopy ou robocopy pour cela). Utile pour sauvegardes rapides ou déploiement de configs.",
    syntax: "copy source destination",
    options: [
      { flag: "/y", desc: "Écrase sans demander confirmation" },
      { flag: "/v", desc: "Vérifie que les fichiers sont écrits correctement" },
      { flag: "/a", desc: "Fichier ASCII" },
      { flag: "/b", desc: "Fichier binaire" }
    ],
    examples: [
      { cmd: "copy rapport.txt backup\\", note: "Copie vers un dossier" },
      { cmd: "copy *.log archives\\", note: "Copie tous les .log" },
      { cmd: "copy fichier.txt fichier_bak.txt", note: "Copie avec nouveau nom" }
    ],
    observe: "Message « 1 fichier(s) copié(s) » en cas de succès.",
    useCases: [
      "Sauvegarde rapide avant modification",
      "Déploiement de fichiers de configuration"
    ],
    errors: [
      "Fichier source introuvable",
      "Destination en lecture seule ou permissions"
    ],
    related: ["move", "xcopy", "robocopy", "del"],
    cyber: "Copier des binaires vers des emplacements de démarrage (Startup) est une technique de persistence classique. Surveiller les copies vers %APPDATA%\\Microsoft\\Windows\\Start Menu\\Programs\\Startup.",
    exercise: {
      objective: "Copier un fichier texte vers un dossier backup.",
      steps: "Créer un fichier puis le copier.",
      solution: "echo test > test.txt\nmkdir backup\ncopy test.txt backup\\"
    }
  },
  {
    id: "move",
    name: "move",
    category: "fichiers",
    level: 1,
    os: ["Windows"],
    tags: ["fichiers", "déplacement"],
    summary: "Déplace ou renomme des fichiers/dossiers.",
    description: "move déplace un fichier ou un dossier d'un endroit à un autre. Si la destination est dans le même dossier, cela revient à un renommage.",
    syntax: "move source destination",
    options: [
      { flag: "/y", desc: "Écrase sans confirmation" }
    ],
    examples: [
      { cmd: "move rapport.txt Archives\\", note: "Déplace vers Archives" },
      { cmd: "move ancien.txt nouveau.txt", note: "Renomme" }
    ],
    observe: "Confirmation si écrasement, puis message de succès.",
    useCases: [
      "Réorganisation de fichiers",
      "Renommage en masse dans un script"
    ],
    errors: [
      "Fichier en cours d'utilisation",
      "Destination invalide"
    ],
    related: ["copy", "ren", "del"],
    cyber: "Déplacer un payload vers un dossier moins surveillé fait partie des techniques d'évasion. Corréler les événements de déplacement de fichiers dans les logs.",
    exercise: {
      objective: "Renommer un fichier via move.",
      steps: "move old.txt new.txt",
      solution: "echo data > old.txt\nmove old.txt new.txt"
    }
  },
  {
    id: "del",
    name: "del",
    category: "fichiers",
    level: 1,
    os: ["Windows"],
    tags: ["fichiers", "suppression"],
    summary: "Supprime un ou plusieurs fichiers.",
    description: "del (ou erase) efface des fichiers. Les jokers (* et ?) sont supportés. Attention : pas de corbeille — la suppression est définitive (sauf recovery avancée).",
    syntax: "del [options] fichier",
    options: [
      { flag: "/p", desc: "Demande confirmation pour chaque fichier" },
      { flag: "/f", desc: "Force la suppression des fichiers en lecture seule" },
      { flag: "/s", desc: "Supprime aussi dans les sous-dossiers" },
      { flag: "/q", desc: "Mode silencieux" }
    ],
    examples: [
      { cmd: "del temp.txt", note: "Supprime un fichier" },
      { cmd: "del *.tmp", note: "Supprime tous les .tmp du dossier" },
      { cmd: "del /s /q *.log", note: "Suppression récursive silencieuse" }
    ],
    observe: "Pas de message par défaut en mode silencieux.",
    useCases: [
      "Nettoyage de fichiers temporaires",
      "Scripts de maintenance"
    ],
    errors: [
      "Fichier en lecture seule → utiliser /f",
      "Fichier verrouillé par un processus"
    ],
    related: ["rmdir", "erase"],
    cyber: "Les malware effacent souvent leurs fichiers temporaires après exécution (anti-forensics). La suppression massive de logs est un signal d'alarme fort.",
    exercise: {
      objective: "Créer puis supprimer un fichier temporaire.",
      steps: "echo x > t.tmp && del t.tmp",
      solution: "echo x > t.tmp\ndel t.tmp"
    }
  },
  {
    id: "type",
    name: "type",
    category: "fichiers",
    level: 1,
    os: ["Windows"],
    tags: ["fichiers", "lecture"],
    summary: "Affiche le contenu d'un fichier texte.",
    description: "type envoie le contenu d'un fichier texte vers la console. Idéal pour lire rapidement des logs, configs ou scripts sans ouvrir un éditeur.",
    syntax: "type fichier",
    options: [],
    examples: [
      { cmd: "type notes.txt", note: "Affiche le contenu" },
      { cmd: "type C:\\Windows\\System32\\drivers\\etc\\hosts", note: "Lit le fichier hosts" }
    ],
    observe: "Le texte défile dans la console. Pour les longs fichiers, combinez avec more : type gros.log | more",
    useCases: [
      "Lecture rapide de logs",
      "Vérification de fichiers de configuration",
      "Inspection de scripts Batch"
    ],
    errors: [
      "Fichier binaire → caractères illisibles",
      "Fichier introuvable"
    ],
    related: ["more", "findstr", "notepad"],
    cyber: "Lire hosts, scripts de démarrage ou fichiers de configuration est une étape classique de reconnaissance locale (living-off-the-land).",
    exercise: {
      objective: "Créer un fichier et afficher son contenu.",
      steps: "echo Hello > h.txt && type h.txt",
      solution: "echo Hello CYBER LAB > h.txt\ntype h.txt"
    }
  },
  {
    id: "tree",
    name: "tree",
    category: "fichiers",
    level: 1,
    os: ["Windows"],
    tags: ["dossiers", "arborescence"],
    summary: "Affiche l'arborescence des dossiers de façon graphique.",
    description: "tree dessine une représentation textuelle de la structure des répertoires. Très utile pour visualiser rapidement l'organisation d'un projet ou d'un volume.",
    syntax: "tree [chemin] [options]",
    options: [
      { flag: "/f", desc: "Affiche aussi les fichiers" },
      { flag: "/a", desc: "Utilise des caractères ASCII au lieu d'Unicode" }
    ],
    examples: [
      { cmd: "tree", note: "Arborescence du dossier courant" },
      { cmd: "tree /f C:\\Users\\Public", note: "Avec fichiers" },
      { cmd: "tree /a > arbo.txt", note: "Exporte dans un fichier" }
    ],
    observe: "Une structure en branches avec ├── et └── (ou ASCII).",
    useCases: [
      "Documenter la structure d'un projet",
      "Repérer des dossiers inhabituels en profondeur"
    ],
    errors: [
      "Chemins trop profonds peuvent produire une sortie très longue"
    ],
    related: ["dir", "cd"],
    cyber: "Cartographier l'arborescence d'un système compromis aide à identifier les emplacements de persistence et de staging.",
    exercise: {
      objective: "Afficher l'arborescence avec fichiers du dossier courant.",
      steps: "tree /f",
      solution: "tree /f"
    }
  },
  {
    id: "echo",
    name: "echo",
    category: "automatisation",
    level: 1,
    os: ["Windows"],
    tags: ["affichage", "batch", "variables"],
    summary: "Affiche un message ou active/désactive l'écho des commandes.",
    description: "echo affiche du texte à l'écran. Dans les scripts Batch, echo off désactive l'affichage des commandes elles-mêmes (plus propre). echo. produit une ligne vide. C'est aussi la façon standard d'écrire dans un fichier via redirection.",
    syntax: "echo message\necho on | off\necho.",
    options: [],
    examples: [
      { cmd: "echo Hello CYBER LAB", note: "Affiche un message" },
      { cmd: "echo %USERNAME%", note: "Affiche une variable d'environnement" },
      { cmd: "echo Ligne > fichier.txt", note: "Écrit dans un fichier (écrase)" },
      { cmd: "echo Ligne >> fichier.txt", note: "Ajoute à la fin du fichier" },
      { cmd: "echo off", note: "Désactive l'écho (dans un .bat)" }
    ],
    observe: "Le texte apparaît immédiatement. Avec redirection, un fichier est créé/modifié.",
    useCases: [
      "Messages dans les scripts",
      "Création rapide de fichiers texte",
      "Debug de variables"
    ],
    errors: [
      "Caractères spéciaux (& | < >) doivent être échappés ou entre guillemets"
    ],
    related: ["set", "type", "cls"],
    cyber: "Les scripts malveillants utilisent souvent echo pour générer des payloads ou des configs à la volée. Analyser les redirections dans les scripts suspects.",
    exercise: {
      objective: "Créer un fichier notes.txt contenant votre prénom via echo.",
      steps: "echo VotreNom > notes.txt puis type notes.txt",
      solution: "echo Student > notes.txt\ntype notes.txt"
    }
  },
  {
    id: "cls",
    name: "cls",
    category: "systeme",
    level: 1,
    os: ["Windows"],
    tags: ["affichage"],
    summary: "Efface l'écran de la console.",
    description: "cls (clear screen) vide complètement l'affichage de la fenêtre d'invite de commandes. Utile pour y voir plus clair après de longues sorties.",
    syntax: "cls",
    options: [],
    examples: [
      { cmd: "cls", note: "Nettoie l'écran" }
    ],
    observe: "L'écran devient vide, le prompt réapparaît en haut.",
    useCases: [
      "Lisibilité pendant une session interactive",
      "Début de script pour un affichage propre"
    ],
    errors: [],
    related: ["echo"],
    cyber: "Peu d'intérêt offensif, mais dans un script d'attaque l'effacement de l'écran peut masquer des messages d'erreur aux yeux d'un utilisateur non technique.",
    exercise: {
      objective: "Afficher plusieurs lignes puis nettoyer l'écran.",
      steps: "dir puis cls",
      solution: "dir\ncls"
    }
  },
  // ─── RÉSEAU ─────────────────────────────────────────────
  {
    id: "ipconfig",
    name: "ipconfig",
    category: "reseau",
    level: 1,
    os: ["Windows"],
    tags: ["réseau", "IP", "DNS", "adaptateur"],
    summary: "Affiche la configuration IP des interfaces réseau.",
    description: "ipconfig est l'outil de base pour connaître l'adresse IP, le masque de sous-réseau, la passerelle par défaut et les serveurs DNS de chaque carte réseau. Avec /all on obtient aussi l'adresse MAC, le serveur DHCP, les suffixes DNS, etc. C'est souvent la première commande exécutée lors d'un diagnostic réseau.",
    syntax: "ipconfig [options]",
    options: [
      { flag: "/all", desc: "Configuration complète (MAC, DHCP, DNS...)" },
      { flag: "/release", desc: "Libère l'adresse IP obtenue via DHCP" },
      { flag: "/renew", desc: "Demande une nouvelle adresse au serveur DHCP" },
      { flag: "/flushdns", desc: "Vide le cache résolveur DNS local" },
      { flag: "/displaydns", desc: "Affiche le contenu du cache DNS" },
      { flag: "/registerdns", desc: "Réenregistre les noms DNS" }
    ],
    examples: [
      { cmd: "ipconfig", note: "Vue résumée (IP, masque, passerelle)" },
      { cmd: "ipconfig /all", note: "Vue détaillée de toutes les interfaces" },
      { cmd: "ipconfig /flushdns", note: "Vide le cache DNS (après changement de DNS)" },
      { cmd: "ipconfig /release && ipconfig /renew", note: "Renouvelle l'IP DHCP" }
    ],
    observe: "Pour chaque adaptateur : IPv4, masque, passerelle. Avec /all : adresse physique (MAC), DHCP activé ou non, serveurs DNS, bail DHCP.",
    useCases: [
      "Vérifier que la machine a bien une IP",
      "Trouver la passerelle pour un traceroute",
      "Diagnostiquer un problème DNS (flushdns)",
      "Noter l'adresse MAC pour un filtrage"
    ],
    errors: [
      "« Media disconnected » → câble débranché ou Wi-Fi off",
      "APIPA (169.254.x.x) → pas de serveur DHCP joignable"
    ],
    related: ["ping", "nslookup", "netstat", "route", "getmac"],
    cyber: "En reconnaissance interne, ipconfig /all révèle le plan d'adressage, les DNS internes et parfois des suffixes de domaine Active Directory. /flushdns est aussi utilisé après empoisonnement de cache pour forcer une nouvelle résolution.",
    exercise: {
      objective: "Afficher la configuration complète et identifier votre adresse IPv4 et votre passerelle.",
      steps: "Lancez ipconfig /all et repérez les champs IPv4 Address et Default Gateway.",
      solution: "ipconfig /all"
    }
  },
  {
    id: "ping",
    name: "ping",
    category: "reseau",
    level: 1,
    os: ["Windows"],
    tags: ["réseau", "ICMP", "connectivité"],
    summary: "Teste la connectivité vers un hôte via ICMP Echo.",
    description: "ping envoie des paquets ICMP Echo Request et attend des Echo Reply. Il mesure le temps d'aller-retour (RTT) et indique si la cible est joignable. C'est le premier réflexe pour vérifier qu'une machine ou un site est accessible.",
    syntax: "ping [options] cible",
    options: [
      { flag: "-n N", desc: "Nombre de requêtes (défaut 4)" },
      { flag: "-t", desc: "Ping continu (Ctrl+C pour arrêter)" },
      { flag: "-l taille", desc: "Taille du buffer d'envoi" },
      { flag: "-w timeout", desc: "Délai d'attente en ms" },
      { flag: "-4 / -6", desc: "Forcer IPv4 ou IPv6" }
    ],
    examples: [
      { cmd: "ping 8.8.8.8", note: "Test vers le DNS Google" },
      { cmd: "ping www.example.com", note: "Test avec résolution DNS" },
      { cmd: "ping -n 10 192.168.1.1", note: "10 paquets vers la box" },
      { cmd: "ping -t 10.0.0.1", note: "Ping continu" }
    ],
    observe: "Réponses avec temps en ms, TTL. En cas d'échec : « Délai de la demande dépassé » ou « Hôte introuvable ».",
    useCases: [
      "Vérifier la connectivité Internet ou LAN",
      "Mesurer la latence",
      "Tester si un serveur répond encore"
    ],
    errors: [
      "Pare-feu qui bloque ICMP → fausse impression d'hôte down",
      "Nom non résolu → problème DNS, pas forcément réseau"
    ],
    related: ["tracert", "pathping", "nslookup", "ipconfig"],
    cyber: "Le ping est utilisé en reconnaissance pour découvrir les hôtes vivants (sweep). Attention : beaucoup de réseaux bloquent ICMP. Un TTL anormalement bas ou élevé peut indiquer un hop supplémentaire (proxy, tunnel).",
    exercise: {
      objective: "Pinger 8.8.8.8 avec 6 paquets et noter le temps moyen.",
      steps: "ping -n 6 8.8.8.8",
      solution: "ping -n 6 8.8.8.8"
    }
  },
  {
    id: "tracert",
    name: "tracert",
    category: "reseau",
    level: 2,
    os: ["Windows"],
    tags: ["réseau", "routage", "chemin"],
    summary: "Trace le chemin des paquets jusqu'à une destination.",
    description: "tracert (traceroute) envoie des paquets avec un TTL croissant pour découvrir chaque routeur intermédiaire. Il affiche la liste des hops avec leurs temps de réponse. Essentiel pour comprendre où un trafic est ralenti ou bloqué.",
    syntax: "tracert [options] cible",
    options: [
      { flag: "-d", desc: "Ne pas résoudre les noms (plus rapide)" },
      { flag: "-h N", desc: "Nombre max de hops" },
      { flag: "-w timeout", desc: "Délai d'attente par réponse" }
    ],
    examples: [
      { cmd: "tracert 8.8.8.8", note: "Chemin vers Google DNS" },
      { cmd: "tracert -d www.example.com", note: "Sans résolution inverse" }
    ],
    observe: "Liste numérotée de hops avec 3 temps (ms) et l'IP (ou nom) de chaque routeur. Des étoiles (*) indiquent un timeout sur ce hop.",
    useCases: [
      "Diagnostiquer où le trafic est perdu",
      "Identifier un goulot d'étranglement",
      "Comprendre la topologie approximative"
    ],
    errors: [
      "Beaucoup de * → routeurs qui ne répondent pas à ICMP",
      "Pare-feu qui limite la visibilité"
    ],
    related: ["ping", "pathping", "route"],
    cyber: "En reconnaissance, traceroute révèle des segments de réseau et parfois des noms internes. Des chemins inhabituels peuvent signaler un détournement de trafic (BGP hijack, tunnel).",
    exercise: {
      objective: "Tracer la route vers 1.1.1.1 sans résolution de noms.",
      steps: "tracert -d 1.1.1.1",
      solution: "tracert -d 1.1.1.1"
    }
  },
  {
    id: "nslookup",
    name: "nslookup",
    category: "reseau",
    level: 2,
    os: ["Windows"],
    tags: ["DNS", "résolution", "noms"],
    summary: "Interroge les serveurs DNS pour résoudre des noms.",
    description: "nslookup (Name Server Lookup) permet de résoudre un nom de domaine en adresse IP et inversement, et d'interroger des types d'enregistrements spécifiques (A, MX, NS, TXT...). Mode interactif ou one-shot.",
    syntax: "nslookup [nom]\nnslookup [nom] [serveur_dns]",
    options: [
      { flag: "set type=MX", desc: "En mode interactif : type d'enregistrement" },
      { flag: "set type=TXT", desc: "Enregistrements texte (SPF, DKIM...)" },
      { flag: "server 8.8.8.8", desc: "Change le serveur DNS interrogé" }
    ],
    examples: [
      { cmd: "nslookup google.com", note: "Résolution A classique" },
      { cmd: "nslookup google.com 1.1.1.1", note: "Via Cloudflare DNS" },
      { cmd: "nslookup -type=MX gmail.com", note: "Serveurs mail" }
    ],
    observe: "Serveur DNS utilisé, puis réponse avec adresse(s) IP ou autres records.",
    useCases: [
      "Vérifier qu'un nom résout correctement",
      "Comparer les réponses de différents DNS",
      "Inspecter les records MX / TXT d'un domaine"
    ],
    errors: [
      "Non-existent domain → nom incorrect ou zone absente",
      "Timeout → DNS inaccessible"
    ],
    related: ["ipconfig", "ping", "resolv"],
    cyber: "nslookup est un outil OSINT de base pour la cartographie DNS. Les records TXT peuvent contenir des infos (SPF, vérification de domaine). Comparer les réponses de plusieurs DNS détecte parfois du DNS spoofing local.",
    exercise: {
      objective: "Résoudre example.com et noter l'adresse IP retournée.",
      steps: "nslookup example.com",
      solution: "nslookup example.com"
    }
  },
  {
    id: "netstat",
    name: "netstat",
    category: "reseau",
    level: 2,
    os: ["Windows"],
    tags: ["réseau", "connexions", "ports"],
    summary: "Affiche les connexions réseau et les ports en écoute.",
    description: "netstat (network statistics) liste les connexions TCP/UDP actives, les ports en écoute, et peut associer les processus (PID). Indispensable pour voir ce qui communique sur la machine.",
    syntax: "netstat [options]",
    options: [
      { flag: "-a", desc: "Toutes les connexions et ports en écoute" },
      { flag: "-n", desc: "Adresses et ports numériques (pas de résolution)" },
      { flag: "-o", desc: "Affiche le PID du processus" },
      { flag: "-b", desc: "Affiche l'exécutable (admin)" },
      { flag: "-ano", desc: "Combinaison très utilisée" },
      { flag: "-r", desc: "Table de routage" },
      { flag: "-e", desc: "Statistiques Ethernet" }
    ],
    examples: [
      { cmd: "netstat -ano", note: "Connexions + PID (classique)" },
      { cmd: "netstat -an | findstr LISTENING", note: "Uniquement les ports en écoute" },
      { cmd: "netstat -b", note: "Avec nom d'exécutable (élevé)" }
    ],
    observe: "Colonnes : Proto, Adresse locale, Adresse distante, État (LISTENING, ESTABLISHED, TIME_WAIT...), PID.",
    useCases: [
      "Trouver quel processus écoute sur un port",
      "Détecter des connexions sortantes suspectes",
      "Vérifier qu'un service est bien démarré"
    ],
    errors: [
      "-b nécessite des privilèges élevés",
      "Beaucoup de lignes → filtrer avec findstr"
    ],
    related: ["tasklist", "taskkill", "ipconfig"],
    cyber: "netstat -ano est l'une des premières commandes en triage d'incident. Une connexion ESTABLISHED vers une IP inconnue + un PID inhabituel = alerte. Corréler le PID avec tasklist /svc.",
    exercise: {
      objective: "Lister les ports en écoute et repérer ceux qui utilisent le port 443 ou 80.",
      steps: "netstat -ano | findstr LISTENING",
      solution: "netstat -ano"
    }
  },
  {
    id: "arp",
    name: "arp",
    category: "reseau",
    level: 2,
    os: ["Windows"],
    tags: ["réseau", "MAC", "ARP"],
    summary: "Affiche ou modifie le cache de résolution IP → MAC.",
    description: "arp gère la table ARP (Address Resolution Protocol) qui associe adresses IP et adresses MAC sur le réseau local. Utile pour voir les voisins de couche 2 ou diagnostiquer des conflits.",
    syntax: "arp -a\narp -d [ip]\narp -s ip mac",
    options: [
      { flag: "-a", desc: "Affiche le cache ARP" },
      { flag: "-d", desc: "Supprime une entrée (ou * pour tout)" },
      { flag: "-s", desc: "Ajoute une entrée statique" }
    ],
    examples: [
      { cmd: "arp -a", note: "Liste le cache ARP" },
      { cmd: "arp -d *", note: "Vide le cache ARP" }
    ],
    observe: "Liste IP → adresse physique (MAC) + type (dynamique/statique).",
    useCases: [
      "Voir les machines du LAN récemment contactées",
      "Diagnostiquer un conflit d'IP",
      "Forcer le renouvellement du cache"
    ],
    errors: [
      "Entrées manquantes si pas de communication récente"
    ],
    related: ["ipconfig", "ping", "getmac"],
    cyber: "L'empoisonnement ARP (ARP spoofing) permet des attaques Man-in-the-Middle sur le LAN. Surveiller des changements brutaux de MAC pour une même IP est une technique de détection.",
    exercise: {
      objective: "Afficher le cache ARP de votre machine.",
      steps: "arp -a",
      solution: "arp -a"
    }
  },
  {
    id: "getmac",
    name: "getmac",
    category: "reseau",
    level: 1,
    os: ["Windows"],
    tags: ["MAC", "réseau"],
    summary: "Affiche les adresses MAC des interfaces réseau.",
    description: "getmac liste les adresses physiques (MAC) de chaque carte réseau, avec le nom du transport associé. Plus simple qu'ipconfig /all quand on ne veut que les MAC.",
    syntax: "getmac [/v] [/fo format]",
    options: [
      { flag: "/v", desc: "Mode verbeux (plus d'infos)" },
      { flag: "/fo list", desc: "Format liste" },
      { flag: "/fo csv", desc: "Format CSV" }
    ],
    examples: [
      { cmd: "getmac", note: "Liste simple" },
      { cmd: "getmac /v /fo list", note: "Détails" }
    ],
    observe: "Adresse physique et nom de connexion.",
    useCases: [
      "Inventaire des interfaces",
      "Filtrage par MAC sur un switch ou DHCP"
    ],
    errors: [],
    related: ["ipconfig", "arp"],
    cyber: "L'adresse MAC peut servir d'identifiant faible. Le spoofing de MAC est possible ; ne jamais s'y fier pour de l'authentification forte.",
    exercise: {
      objective: "Afficher vos adresses MAC en mode verbeux.",
      steps: "getmac /v",
      solution: "getmac /v"
    }
  },
  // ─── UTILISATEUR / SYSTÈME ──────────────────────────────
  {
    id: "whoami",
    name: "whoami",
    category: "systeme",
    level: 1,
    os: ["Windows"],
    tags: ["utilisateur", "identité"],
    summary: "Affiche le nom de l'utilisateur courant.",
    description: "whoami retourne le nom du compte sous lequel la session (ou le processus) s'exécute, au format DOMAINE\\utilisateur ou MACHINE\\utilisateur. Avec des options, on peut lister les groupes et privilèges.",
    syntax: "whoami [/all] [/groups] [/priv]",
    options: [
      { flag: "/all", desc: "SID, groupes, privilèges" },
      { flag: "/groups", desc: "Groupes d'appartenance" },
      { flag: "/priv", desc: "Privilèges de la session" },
      { flag: "/upn", desc: "User Principal Name" },
      { flag: "/fqdn", desc: "Nom de domaine complet" }
    ],
    examples: [
      { cmd: "whoami", note: "Nom simple" },
      { cmd: "whoami /groups", note: "Groupes" },
      { cmd: "whoami /priv", note: "Privilèges (SeDebugPrivilege...)" },
      { cmd: "whoami /all", note: "Vue complète" }
    ],
    observe: "Ex: desktop-abc\\student ou CORP\\jdupont. Avec /priv : liste Enabled/Disabled.",
    useCases: [
      "Vérifier sous quel compte un script tourne",
      "Contrôler les privilèges avant une action admin",
      "Audit de session"
    ],
    errors: [],
    related: ["hostname", "net user", "systeminfo"],
    cyber: "whoami /priv est critique en post-exploitation pour savoir si SeImpersonatePrivilege ou SeDebugPrivilege sont disponibles (escalade). En Blue Team, un processus qui s'exécute sous un compte inattendu est un signal.",
    exercise: {
      objective: "Afficher votre identité et vos groupes.",
      steps: "whoami && whoami /groups",
      solution: "whoami\nwhoami /groups"
    }
  },
  {
    id: "hostname",
    name: "hostname",
    category: "systeme",
    level: 1,
    os: ["Windows"],
    tags: ["système", "nom"],
    summary: "Affiche le nom d'hôte de l'ordinateur.",
    description: "hostname retourne simplement le nom NetBIOS / hostname de la machine. Utile dans les scripts pour identifier sur quelle machine on se trouve.",
    syntax: "hostname",
    options: [],
    examples: [
      { cmd: "hostname", note: "Affiche le nom" }
    ],
    observe: "Une seule ligne avec le nom (ex: LAB-PC-01).",
    useCases: [
      "Identification dans les logs et scripts",
      "Inventaire"
    ],
    errors: [],
    related: ["whoami", "systeminfo"],
    cyber: "Le hostname apparaît dans de nombreux artefacts (logs, noms de fichiers de dump, user-agents). Uniformiser les noms aide l'investigation ; des hostnames aléatoires peuvent indiquer des machines éphémères ou compromises.",
    exercise: {
      objective: "Afficher le nom de votre machine.",
      steps: "hostname",
      solution: "hostname"
    }
  },
  {
    id: "systeminfo",
    name: "systeminfo",
    category: "systeme",
    level: 1,
    os: ["Windows"],
    tags: ["système", "inventaire"],
    summary: "Affiche un inventaire détaillé de la configuration système.",
    description: "systeminfo produit un rapport complet : version OS, fabricant, processeur, mémoire, correctifs installés, cartes réseau, domaine, etc. Très riche pour un inventaire rapide ou un triage.",
    syntax: "systeminfo [/s ordinateur] [/fo format]",
    options: [
      { flag: "/fo csv", desc: "Sortie CSV" },
      { flag: "/fo list", desc: "Format liste" }
    ],
    examples: [
      { cmd: "systeminfo", note: "Rapport complet" },
      { cmd: "systeminfo | findstr /B /C:\"OS Name\" /C:\"OS Version\"", note: "Filtrer version OS" }
    ],
    observe: "De nombreuses sections : Nom de l'OS, Version, Fabricant, Processeur, Mémoire physique totale, Correctifs, Carte(s) réseau...",
    useCases: [
      "Inventaire rapide d'une machine",
      "Vérifier les correctifs installés",
      "Connaître le rôle (Workstation / Domain Controller)"
    ],
    errors: [
      "Peut être lent sur certaines machines",
      "Certaines infos nécessitent des droits élevés"
    ],
    related: ["whoami", "hostname", "tasklist"],
    cyber: "systeminfo révèle le niveau de patch (hotfixes). Un système non patché est une cible prioritaire. En reconnaissance, c'est une mine d'informations sur la configuration.",
    exercise: {
      objective: "Extraire uniquement le nom et la version de l'OS.",
      steps: "systeminfo | findstr /C:\"OS Name\" /C:\"OS Version\"",
      solution: "systeminfo | findstr /B /C:\"OS Name\" /C:\"OS Version\""
    }
  },
  {
    id: "tasklist",
    name: "tasklist",
    category: "processus",
    level: 1,
    os: ["Windows"],
    tags: ["processus", "PID"],
    summary: "Liste les processus en cours d'exécution.",
    description: "tasklist affiche tous les processus avec leur PID, le nom de la session et l'utilisation mémoire. Avec /svc on voit les services hébergés. Essentiel pour le diagnostic et la chasse aux processus suspects.",
    syntax: "tasklist [options]",
    options: [
      { flag: "/v", desc: "Mode verbeux (fenêtre, utilisateur...)" },
      { flag: "/svc", desc: "Services associés aux processus" },
      { flag: "/m", desc: "Modules (DLL) chargés" },
      { flag: "/fi \"filtre\"", desc: "Filtre (ex: imagename eq chrome.exe)" },
      { flag: "/fo csv", desc: "Sortie CSV" }
    ],
    examples: [
      { cmd: "tasklist", note: "Liste standard" },
      { cmd: "tasklist /v", note: "Détails + utilisateur" },
      { cmd: "tasklist /svc", note: "Services par processus" },
      { cmd: "tasklist /fi \"imagename eq notepad.exe\"", note: "Filtrer un processus" }
    ],
    observe: "Nom d'image, PID, nom de session, N° session, usage mémoire.",
    useCases: [
      "Identifier un processus qui consomme trop de RAM/CPU",
      "Trouver le PID avant un taskkill",
      "Voir sous quel utilisateur tourne un process"
    ],
    errors: [],
    related: ["taskkill", "netstat", "whoami"],
    cyber: "Comparer tasklist avec une baseline est une technique de détection. Des processus avec des noms ressemblant à des binaires système (svchost.exe mal placé) ou des chemins inhabituels sont des IOC classiques.",
    exercise: {
      objective: "Lister les processus et repérer le PID de votre explorateur (explorer.exe).",
      steps: "tasklist | findstr explorer",
      solution: "tasklist | findstr explorer.exe"
    }
  },
  {
    id: "taskkill",
    name: "taskkill",
    category: "processus",
    level: 2,
    os: ["Windows"],
    tags: ["processus", "arrêt"],
    summary: "Termine un ou plusieurs processus.",
    description: "taskkill arrête des processus par PID ou par nom d'image. /f force l'arrêt. À utiliser avec précaution : tuer un processus système critique peut déstabiliser la machine.",
    syntax: "taskkill /PID pid [/f]\ntaskkill /IM nom.exe [/f]",
    options: [
      { flag: "/PID", desc: "Par identifiant de processus" },
      { flag: "/IM", desc: "Par nom d'image (ex: notepad.exe)" },
      { flag: "/F", desc: "Force la terminaison" },
      { flag: "/T", desc: "Termine aussi les processus enfants" }
    ],
    examples: [
      { cmd: "taskkill /IM notepad.exe", note: "Ferme Notepad" },
      { cmd: "taskkill /PID 1234 /F", note: "Force l'arrêt du PID 1234" },
      { cmd: "taskkill /IM chrome.exe /T /F", note: "Chrome + enfants, forcé" }
    ],
    observe: "Message de succès ou d'échec (accès refusé, processus introuvable).",
    useCases: [
      "Fermer une application qui ne répond plus",
      "Scripts de nettoyage",
      "Arrêter un processus suspect (après analyse)"
    ],
    errors: [
      "Accès refusé → droits insuffisants ou processus protégé",
      "PID incorrect"
    ],
    related: ["tasklist", "wmic"],
    cyber: "Les défenseurs tuent les processus malveillants après isolation. Les attaquants peuvent aussi tuer l'antivirus ou les agents EDR (si permissions). Surveiller les taskkill sur des processus de sécurité est un signal d'alerte.",
    exercise: {
      objective: "Ouvrir notepad, trouver son PID, puis le terminer.",
      steps: "start notepad → tasklist | findstr notepad → taskkill /PID xxx",
      solution: "start notepad\ntasklist | findstr notepad.exe\ntaskkill /IM notepad.exe"
    }
  },
  {
    id: "ver",
    name: "ver",
    category: "systeme",
    level: 1,
    os: ["Windows"],
    tags: ["version"],
    summary: "Affiche la version de Windows.",
    description: "ver retourne la version du système d'exploitation de façon très concise. Moins détaillé que systeminfo mais instantané.",
    syntax: "ver",
    options: [],
    examples: [
      { cmd: "ver", note: "Version Windows" }
    ],
    observe: "Ex: Microsoft Windows [version 10.0.19045.3803]",
    useCases: [
      "Vérification rapide de version dans un script"
    ],
    errors: [],
    related: ["systeminfo"],
    cyber: "Connaître la build exacte permet de savoir quels CVE s'appliquent. Automatiser la collecte de ver / systeminfo sur un parc aide à prioriser les patchs.",
    exercise: {
      objective: "Afficher la version de Windows.",
      steps: "ver",
      solution: "ver"
    }
  },
  // ─── AUTOMATISATION / BATCH ─────────────────────────────
  {
    id: "set",
    name: "set",
    category: "automatisation",
    level: 2,
    os: ["Windows"],
    tags: ["variables", "environnement", "batch"],
    summary: "Affiche ou définit des variables d'environnement.",
    description: "set sans argument liste toutes les variables d'environnement. set NOM=valeur les définit pour la session courante. set /a permet des calculs arithmétiques, set /p lit une saisie utilisateur. Fondamental en Batch.",
    syntax: "set\nset NOM=valeur\nset /a NOM=expression\nset /p NOM=prompt",
    options: [
      { flag: "/a", desc: "Évaluation arithmétique" },
      { flag: "/p", desc: "Lecture depuis l'entrée utilisateur" }
    ],
    examples: [
      { cmd: "set", note: "Liste toutes les variables" },
      { cmd: "set PATH", note: "Affiche uniquement PATH" },
      { cmd: "set LAB=CYBER", note: "Définit LAB" },
      { cmd: "echo %LAB%", note: "Utilise la variable" },
      { cmd: "set /a RESULT=10+5", note: "Calcul" },
      { cmd: "set /p NAME=Votre nom: ", note: "Saisie" }
    ],
    observe: "Liste NOM=valeur. Les variables sont accessibles via %NOM%.",
    useCases: [
      "Configuration de scripts",
      "Stockage temporaire de valeurs",
      "Manipulation du PATH"
    ],
    errors: [
      "Oublier les % pour développer une variable",
      "set NOM = valeur (espaces autour du = créent un nom avec espace)"
    ],
    related: ["echo", "setx", "path"],
    cyber: "Les variables d'environnement peuvent contenir des secrets (clés API mal placées). set affiche tout — attention dans les captures d'écran. Des malware modifient PATH pour intercepter des exécutions.",
    exercise: {
      objective: "Créer une variable COURS=Reseaux et l'afficher.",
      steps: "set COURS=Reseaux puis echo %COURS%",
      solution: "set COURS=Reseaux\necho %COURS%"
    }
  },
  {
    id: "if",
    name: "if",
    category: "automatisation",
    level: 2,
    os: ["Windows"],
    tags: ["batch", "conditions"],
    summary: "Exécute des commandes sous condition (Batch).",
    description: "if permet les branchements conditionnels dans les scripts .bat : tester l'existence d'un fichier, comparer des chaînes ou des codes d'erreur (errorlevel).",
    syntax: "if condition commande\nif exist fichier commande\nif \"%VAR%\"==\"valeur\" commande\nif errorlevel N commande",
    options: [
      { flag: "exist", desc: "Teste l'existence d'un fichier/dossier" },
      { flag: "errorlevel", desc: "Teste le code retour de la dernière commande" },
      { flag: "not", desc: "Négation" },
      { flag: "/i", desc: "Comparaison insensible à la casse" }
    ],
    examples: [
      { cmd: "if exist notes.txt echo Fichier présent", note: "Test fichier" },
      { cmd: "if \"%USERNAME%\"==\"student\" echo Bienvenue étudiant", note: "Test variable" },
      { cmd: "if not exist backup mkdir backup", note: "Création conditionnelle" }
    ],
    observe: "La commande après la condition ne s'exécute que si le test est vrai.",
    useCases: [
      "Scripts robustes qui vérifient prérequis",
      "Gestion d'erreurs simple",
      "Menus Batch"
    ],
    errors: [
      "Guillemets mal placés autour des variables",
      "Confusion entre = et =="
    ],
    related: ["for", "goto", "set"],
    cyber: "Les scripts d'installation ou de malware utilisent if exist pour éviter d'écraser ou pour brancher selon l'environnement (présence d'un AV, d'un debugger...).",
    exercise: {
      objective: "Écrire une ligne qui crée le dossier logs s'il n'existe pas.",
      steps: "if not exist logs mkdir logs",
      solution: "if not exist logs mkdir logs"
    }
  },
  {
    id: "for",
    name: "for",
    category: "automatisation",
    level: 2,
    os: ["Windows"],
    tags: ["batch", "boucles"],
    summary: "Boucle sur des fichiers, des chaînes ou des commandes.",
    description: "for est la structure de boucle principale en Batch. Elle peut itérer sur des fichiers, des listes de valeurs, ou le résultat d'une commande. Puissante mais syntaxe particulière.",
    syntax: "for %%V in (liste) do commande\nfor /f %%V in ('commande') do ...\nfor /l %%V in (start,step,end) do ...",
    options: [
      { flag: "/f", desc: "Parse le résultat d'une commande ou d'un fichier" },
      { flag: "/l", desc: "Boucle numérique" },
      { flag: "/d", desc: "Itère sur les dossiers" },
      { flag: "/r", desc: "Récursif" }
    ],
    examples: [
      { cmd: "for %f in (*.txt) do echo %f", note: "Liste les .txt (en console % simple)" },
      { cmd: "for /l %i in (1,1,5) do echo Numero %i", note: "Boucle 1 à 5" },
      { cmd: "for /f %i in ('dir /b') do echo Fichier: %i", note: "Parse la sortie de dir" }
    ],
    observe: "En console interactive on utilise %v ; dans un fichier .bat on utilise %%v.",
    useCases: [
      "Traitement par lot de fichiers",
      "Scripts d'inventaire",
      "Automatisation répétitive"
    ],
    errors: [
      "Oublier le double % dans les .bat",
      "Syntaxe des options /f complexe"
    ],
    related: ["if", "goto", "call"],
    cyber: "Les scripts de reconnaissance ou de nettoyage utilisent for pour parcourir des listes d'hôtes, de fichiers ou de processus. Analyser les boucles for dans un script suspect révèle souvent l'intention.",
    exercise: {
      objective: "Afficher les nombres de 1 à 3 avec for /l.",
      steps: "for /l %i in (1,1,3) do echo %i",
      solution: "for /l %i in (1,1,3) do echo %i"
    }
  },
  {
    id: "findstr",
    name: "findstr",
    category: "recherche",
    level: 2,
    os: ["Windows"],
    tags: ["recherche", "texte", "filtre"],
    summary: "Recherche de chaînes dans des fichiers (type grep).",
    description: "findstr cherche des motifs textuels dans des fichiers ou dans le flux d'entrée. Support d'expressions régulières basiques, recherche récursive, insensible à la casse, etc. L'équivalent le plus proche de grep sous Windows natif.",
    syntax: "findstr [options] motif [fichiers]",
    options: [
      { flag: "/i", desc: "Insensible à la casse" },
      { flag: "/n", desc: "Affiche les numéros de ligne" },
      { flag: "/s", desc: "Recherche dans les sous-dossiers" },
      { flag: "/r", desc: "Motif comme regex" },
      { flag: "/c:\"chaine\"", desc: "Chaîne littérale avec espaces" },
      { flag: "/g:fichier", desc: "Motifs lus depuis un fichier" }
    ],
    examples: [
      { cmd: "findstr /i \"error\" app.log", note: "Cherche error (casse ignorée)" },
      { cmd: "findstr /n /i \"password\" *.txt", note: "Avec numéros de ligne" },
      { cmd: "dir /b | findstr /i \"lab\"", note: "Filtre la sortie de dir" },
      { cmd: "findstr /s /i /m \"TODO\" *.js", note: "Fichiers contenant TODO" }
    ],
    observe: "Lignes correspondantes (et optionnellement nom de fichier + numéro).",
    useCases: [
      "Analyser des logs",
      "Chercher des IOC dans des fichiers texte",
      "Filtrer la sortie d'autres commandes"
    ],
    errors: [
      "Guillemets oubliés pour les motifs avec espaces",
      "Regex limitées par rapport à un vrai grep"
    ],
    related: ["find", "type", "select-string"],
    cyber: "findstr est massivement utilisé en triage pour chercher des chaînes suspectes (password, http://, cmd.exe, powershell -enc...). Combiné à /s il permet un scan rapide d'un disque.",
    exercise: {
      objective: "Créer un fichier contenant plusieurs lignes et extraire celles avec le mot LAB.",
      steps: "echo ... > t.txt puis findstr LAB t.txt",
      solution: "echo Ligne1 > t.txt\necho CYBER LAB >> t.txt\necho Fin >> t.txt\nfindstr /i LAB t.txt"
    }
  },
  {
    id: "where",
    name: "where",
    category: "recherche",
    level: 1,
    os: ["Windows"],
    tags: ["recherche", "PATH", "exécutable"],
    summary: "Localise l'emplacement d'un exécutable dans le PATH.",
    description: "where cherche un fichier dans les répertoires listés par la variable PATH (et éventuellement le dossier courant). Idéal pour savoir quelle version d'une commande sera lancée.",
    syntax: "where [options] nom",
    options: [
      { flag: "/r", desc: "Recherche récursive à partir d'un dossier" }
    ],
    examples: [
      { cmd: "where python", note: "Où est python.exe ?" },
      { cmd: "where notepad", note: "Emplacement de notepad" },
      { cmd: "where /r C:\\Windows notepad.exe", note: "Recherche récursive" }
    ],
    observe: "Chemin(s) complet(s) vers le(s) fichier(s) trouvé(s).",
    useCases: [
      "Vérifier qu'un outil est bien installé et accessible",
      "Détecter des collisions de noms dans le PATH"
    ],
    errors: [
      "« INFO: Impossible de trouver... » → absent du PATH"
    ],
    related: ["set", "dir", "path"],
    cyber: "Si where python pointe vers un chemin inhabituel, cela peut indiquer un hijacking de PATH. Toujours valider l'emplacement des outils sensibles.",
    exercise: {
      objective: "Trouver l'emplacement de cmd.exe.",
      steps: "where cmd",
      solution: "where cmd"
    }
  },
  {
    id: "sc",
    name: "sc",
    category: "systeme",
    level: 3,
    os: ["Windows"],
    tags: ["services", "admin"],
    summary: "Gestion des services Windows (Service Control).",
    description: "sc interroge et contrôle les services Windows : démarrer, arrêter, interroger l'état, créer, supprimer. Nécessite souvent des privilèges élevés. Alternative en ligne de commande à services.msc.",
    syntax: "sc query [nom]\nsc start nom\nsc stop nom\nsc config nom ...",
    options: [
      { flag: "query", desc: "État d'un service ou liste" },
      { flag: "start / stop", desc: "Démarre / arrête" },
      { flag: "config", desc: "Modifie la configuration" },
      { flag: "qc", desc: "Configuration (binaire, type...)" }
    ],
    examples: [
      { cmd: "sc query", note: "Liste des services" },
      { cmd: "sc query Spooler", note: "État du spouleur d'impression" },
      { cmd: "sc qc Spooler", note: "Configuration détaillée" }
    ],
    observe: "STATE (RUNNING, STOPPED...), type de service, code de sortie.",
    useCases: [
      "Diagnostiquer un service qui ne démarre pas",
      "Scripts d'administration",
      "Audit des services au démarrage"
    ],
    errors: [
      "Accès refusé sans élévation",
      "Nom de service incorrect (utiliser le nom court, pas l'affichage)"
    ],
    related: ["net", "services.msc", "tasklist"],
    cyber: "Créer un service est une technique de persistence classique. sc qc révèle le binaire lancé — vérifier les chemins inhabituels. Arrêter un service de sécurité est un geste offensif détectable.",
    exercise: {
      objective: "Interroger l'état du service Themes ou Spooler.",
      steps: "sc query Spooler",
      solution: "sc query Spooler"
    }
  },
  {
    id: "net",
    name: "net",
    category: "systeme",
    level: 2,
    os: ["Windows"],
    tags: ["réseau", "utilisateurs", "partages"],
    summary: "Suite de commandes d'administration réseau et comptes.",
    description: "net est une famille de commandes : net user, net localgroup, net share, net start, net view, net use... Elle permet de gérer les utilisateurs locaux, les groupes, les partages et certains services.",
    syntax: "net user\nnet localgroup\nnet start\nnet share\nnet view",
    options: [],
    examples: [
      { cmd: "net user", note: "Liste des utilisateurs locaux" },
      { cmd: "net user %USERNAME%", note: "Détails sur votre compte" },
      { cmd: "net localgroup Administrators", note: "Membres du groupe Admins" },
      { cmd: "net start", note: "Services démarrés" },
      { cmd: "net share", note: "Partages réseau" }
    ],
    observe: "Selon la sous-commande : listes d'utilisateurs, de groupes, de services ou de partages.",
    useCases: [
      "Audit des comptes locaux",
      "Vérifier les membres d'un groupe privilégié",
      "Lister les partages exposés"
    ],
    errors: [
      "Certaines actions nécessitent des droits admin"
    ],
    related: ["net user", "net localgroup", "whoami", "sc"],
    cyber: "net user et net localgroup sont des commandes de reconnaissance interne standard. Un compte mystérieux dans Administrators est un IOC majeur. net share révèle la surface d'attaque latérale.",
    exercise: {
      objective: "Lister les utilisateurs locaux et les membres du groupe Users.",
      steps: "net user puis net localgroup Users",
      solution: "net user\nnet localgroup Users"
    }
  },
  {
    id: "net-user",
    name: "net user",
    category: "systeme",
    level: 2,
    os: ["Windows"],
    tags: ["utilisateurs", "comptes"],
    summary: "Gère les comptes utilisateurs locaux.",
    description: "net user liste, crée, modifie ou supprime des comptes utilisateurs locaux. Affiche aussi les détails d'un compte (dernière connexion, groupes, etc.).",
    syntax: "net user [nom [mot_de_passe] [/add] [/delete] ...]",
    options: [
      { flag: "/add", desc: "Crée un compte" },
      { flag: "/delete", desc: "Supprime un compte" },
      { flag: "/active:yes|no", desc: "Active ou désactive" }
    ],
    examples: [
      { cmd: "net user", note: "Liste" },
      { cmd: "net user Administrateur", note: "Détails du compte Admin" }
    ],
    observe: "Nom, paramètres de mot de passe, groupes d'appartenance, dernières connexions.",
    useCases: [
      "Audit des comptes",
      "Administration locale (dans un lab contrôlé)"
    ],
    errors: [
      "Droits insuffisants pour créer/supprimer"
    ],
    related: ["net localgroup", "whoami"],
    cyber: "La création de comptes locaux est une technique de persistence. Surveiller les nouveaux comptes et les ajouts au groupe Administrators via les journaux de sécurité (Event ID 4720, 4732).",
    exercise: {
      objective: "Afficher les détails de votre propre compte.",
      steps: "net user %USERNAME%",
      solution: "net user %USERNAME%"
    }
  },
  {
    id: "icacls",
    name: "icacls",
    category: "permissions",
    level: 3,
    os: ["Windows"],
    tags: ["permissions", "ACL", "fichiers"],
    summary: "Affiche et modifie les listes de contrôle d'accès (ACL) des fichiers.",
    description: "icacls (Integrity Control Access Control Lists) permet de visualiser et de changer les permissions NTFS sur fichiers et dossiers. Plus moderne et précis que l'ancien cacls.",
    syntax: "icacls fichier [/grant ...] [/deny ...] [/remove ...]",
    options: [
      { flag: "/grant", desc: "Accorde des droits" },
      { flag: "/deny", desc: "Refuse explicitement" },
      { flag: "/remove", desc: "Supprime des entrées" },
      { flag: "/T", desc: "Récursif" },
      { flag: "/C", desc: "Continue en cas d'erreur" }
    ],
    examples: [
      { cmd: "icacls notes.txt", note: "Affiche les ACL" },
      { cmd: "icacls C:\\Labs /T", note: "ACL récursives" }
    ],
    observe: "SID ou noms d'utilisateurs/groupes avec lettres de droits (F=Full, M=Modify, RX=Read&Execute...).",
    useCases: [
      "Auditer qui a accès à un dossier sensible",
      "Corriger des permissions trop ouvertes",
      "Scripts de durcissement"
    ],
    errors: [
      "Syntaxe des droits complexe",
      "Nécessite souvent des droits élevés pour modifier"
    ],
    related: ["attrib", "takeown", "cacls"],
    cyber: "Des permissions trop permissives (Everyone:F) sont une faiblesse classique. Les malware modifient parfois les ACL pour se protéger ou pour permettre l'écriture dans des emplacements système.",
    exercise: {
      objective: "Afficher les permissions du dossier courant.",
      steps: "icacls .",
      solution: "icacls ."
    }
  },
  {
    id: "attrib",
    name: "attrib",
    category: "permissions",
    level: 2,
    os: ["Windows"],
    tags: ["attributs", "caché", "fichiers"],
    summary: "Affiche ou modifie les attributs des fichiers (caché, système, lecture seule...).",
    description: "attrib gère les attributs DOS/NTFS classiques : Read-only (R), Archive (A), System (S), Hidden (H). Les fichiers cachés ou système n'apparaissent pas toujours avec un simple dir.",
    syntax: "attrib [+R|-R] [+H|-H] [+S|-S] [fichier]",
    options: [
      { flag: "+H / -H", desc: "Ajoute / retire l'attribut Caché" },
      { flag: "+S / -S", desc: "Attribut Système" },
      { flag: "+R / -R", desc: "Lecture seule" },
      { flag: "/S", desc: "Sous-dossiers" }
    ],
    examples: [
      { cmd: "attrib", note: "Attributs des fichiers du dossier" },
      { cmd: "attrib +H secret.txt", note: "Cache le fichier" },
      { cmd: "attrib -H secret.txt", note: "Rend visible" }
    ],
    observe: "Lettres d'attributs devant chaque nom de fichier.",
    useCases: [
      "Masquer/afficher des fichiers",
      "Retirer le lecture seule avant édition"
    ],
    errors: [],
    related: ["dir", "icacls"],
    cyber: "Les malware marquent souvent leurs fichiers +H +S pour se cacher de l'explorateur et de dir sans /a. Toujours utiliser dir /a lors d'un triage.",
    exercise: {
      objective: "Créer un fichier, le cacher, vérifier qu'il n'apparaît plus avec dir simple, puis le réafficher.",
      steps: "echo x > h.txt && attrib +H h.txt && dir && attrib -H h.txt",
      solution: "echo x > h.txt\nattrib +H h.txt\ndir\nattrib -H h.txt\ndir"
    }
  },
  {
    id: "help",
    name: "help",
    category: "systeme",
    level: 1,
    os: ["Windows"],
    tags: ["aide"],
    summary: "Affiche l'aide d'une commande ou la liste des commandes.",
    description: "help sans argument liste les commandes disponibles. help nom_commande affiche la page d'aide de cette commande. La plupart des commandes acceptent aussi /? .",
    syntax: "help [commande]\ncommande /?",
    options: [],
    examples: [
      { cmd: "help", note: "Liste des commandes" },
      { cmd: "help dir", note: "Aide de dir" },
      { cmd: "ipconfig /?", note: "Aide alternative" }
    ],
    observe: "Texte d'aide avec syntaxe et options.",
    useCases: [
      "Découvrir les options d'une commande",
      "Rappel de syntaxe"
    ],
    errors: [],
    related: ["tous"],
    cyber: "Toujours lire l'aide avant d'utiliser une commande méconnue, surtout en production.",
    exercise: {
      objective: "Afficher l'aide de la commande tree.",
      steps: "help tree ou tree /?",
      solution: "tree /?"
    }
  },
  {
    id: "pause",
    name: "pause",
    category: "automatisation",
    level: 1,
    os: ["Windows"],
    tags: ["batch", "interaction"],
    summary: "Suspend l'exécution et attend une touche.",
    description: "pause affiche « Appuyez sur une touche pour continuer... » et attend. Très utilisé dans les scripts Batch pour laisser l'utilisateur lire un message avant de fermer la fenêtre.",
    syntax: "pause",
    options: [],
    examples: [
      { cmd: "pause", note: "Attend une touche" }
    ],
    observe: "Message d'attente, puis reprise après pression d'une touche.",
    useCases: [
      "Scripts interactifs",
      "Éviter la fermeture immédiate d'une fenêtre .bat"
    ],
    errors: [],
    related: ["echo", "timeout"],
    cyber: "Peu d'intérêt offensif. Dans un lab, utile pour freiner l'exécution et observer les étapes.",
    exercise: {
      objective: "Écrire un mini-script qui affiche un message puis pause.",
      steps: "echo Hello & pause",
      solution: "echo Hello CYBER LAB\npause"
    }
  },
  {
    id: "timeout",
    name: "timeout",
    category: "automatisation",
    level: 1,
    os: ["Windows"],
    tags: ["attente", "batch"],
    summary: "Attend un nombre de secondes spécifié.",
    description: "timeout met en pause l'exécution pendant N secondes (ou jusqu'à une touche si autorisé). Plus flexible que pause pour les scripts non interactifs.",
    syntax: "timeout /t secondes [/nobreak]",
    options: [
      { flag: "/t N", desc: "Durée en secondes (-1 = infini)" },
      { flag: "/nobreak", desc: "Ignore les frappes clavier" }
    ],
    examples: [
      { cmd: "timeout /t 5", note: "Attend 5 secondes" },
      { cmd: "timeout /t 10 /nobreak", note: "10 s sans interruption possible" }
    ],
    observe: "Compte à rebours affiché.",
    useCases: [
      "Temporisation dans un script",
      "Attendre qu'un service démarre"
    ],
    errors: [],
    related: ["pause", "ping"],
    cyber: "Des scripts malveillants utilisent des délais pour éviter la détection sandbox (qui timeout rapidement). Un timeout long avant une action réseau peut être un signe.",
    exercise: {
      objective: "Attendre 3 secondes puis afficher « OK ».",
      steps: "timeout /t 3 & echo OK",
      solution: "timeout /t 3\necho OK"
    }
  }
];

// Index rapide par id
const COMMANDS_BY_ID = Object.fromEntries(COMMANDS.map(c => [c.id, c]));
