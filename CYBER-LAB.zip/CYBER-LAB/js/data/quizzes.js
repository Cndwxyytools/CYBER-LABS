/**
 * CYBER LAB — Quiz par module
 */
const QUIZZES = {
  cmd: {
    id: "quiz-cmd",
    title: "Quiz CMD — Bases",
    moduleId: "cmd",
    xp: 20,
    questions: [
      {
        id: "q1",
        type: "mcq",
        question: "Quelle commande affiche le contenu d'un répertoire ?",
        options: ["cd", "dir", "type", "echo"],
        correct: 1,
        explanation: "dir liste les fichiers et dossiers. cd change de répertoire, type affiche le contenu d'un fichier, echo affiche du texte."
      },
      {
        id: "q2",
        type: "mcq",
        question: "Que fait la commande « cd .. » ?",
        options: [
          "Affiche le chemin courant",
          "Remonte d'un niveau dans l'arborescence",
          "Va à la racine du disque",
          "Crée un dossier parent"
        ],
        correct: 1,
        explanation: "cd .. déplace le répertoire de travail vers le dossier parent."
      },
      {
        id: "q3",
        type: "truefalse",
        question: "La commande del envoie les fichiers dans la Corbeille.",
        correct: false,
        explanation: "del supprime définitivement (pas de Corbeille). La récupération éventuelle nécessite des outils forensiques."
      },
      {
        id: "q4",
        type: "mcq",
        question: "Quelle option de ipconfig affiche l'adresse MAC et les serveurs DNS ?",
        options: ["/renew", "/all", "/flushdns", "/release"],
        correct: 1,
        explanation: "ipconfig /all donne la configuration complète de chaque adaptateur."
      },
      {
        id: "q5",
        type: "mcq",
        question: "netstat -ano permet de :",
        options: [
          "Changer d'adresse IP",
          "Voir les connexions réseau et les PID associés",
          "Tester la connectivité ICMP",
          "Résoudre un nom de domaine"
        ],
        correct: 1,
        explanation: "netstat -ano liste les connexions/ports avec le PID du processus responsable."
      },
      {
        id: "q6",
        type: "command",
        question: "Quelle commande affiche le nom de l'utilisateur courant ?",
        answer: "whoami",
        explanation: "whoami retourne le compte sous lequel la session s'exécute."
      },
      {
        id: "q7",
        type: "mcq",
        question: "Pour vider le cache DNS local sous Windows :",
        options: ["ipconfig /renew", "ipconfig /flushdns", "nslookup /clear", "arp -d *"],
        correct: 1,
        explanation: "ipconfig /flushdns vide le cache du résolveur DNS client."
      },
      {
        id: "q8",
        type: "truefalse",
        question: "ping utilise le protocole TCP pour tester la connectivité.",
        correct: false,
        explanation: "ping utilise ICMP (Echo Request / Echo Reply), pas TCP."
      }
    ]
  },
  reseaux: {
    id: "quiz-reseaux",
    title: "Quiz Réseaux — IP & DNS",
    moduleId: "reseaux",
    xp: 20,
    questions: [
      {
        id: "q1",
        type: "mcq",
        question: "Combien de bits compose une adresse IPv4 ?",
        options: ["16", "32", "64", "128"],
        correct: 1,
        explanation: "IPv4 = 32 bits (4 octets). IPv6 = 128 bits."
      },
      {
        id: "q2",
        type: "mcq",
        question: "Le masque 255.255.255.0 correspond en CIDR à :",
        options: ["/8", "/16", "/24", "/32"],
        correct: 2,
        explanation: "255.255.255.0 = 24 bits à 1 → /24."
      },
      {
        id: "q3",
        type: "mcq",
        question: "Quelle plage est privée selon RFC 1918 ?",
        options: ["8.8.8.0/24", "192.168.0.0/16", "1.1.1.0/24", "208.67.222.0/24"],
        correct: 1,
        explanation: "192.168.0.0/16 (ainsi que 10.0.0.0/8 et 172.16.0.0/12) sont privées."
      },
      {
        id: "q4",
        type: "truefalse",
        question: "DNS traduit les noms de domaine en adresses IP.",
        correct: true,
        explanation: "C'est le rôle principal du DNS (résolution de noms)."
      },
      {
        id: "q5",
        type: "mcq",
        question: "Le protocole utilisé par défaut pour un serveur web sécurisé est :",
        options: ["FTP sur le port 21", "HTTP sur le port 80", "HTTPS sur le port 443", "SSH sur le port 22"],
        correct: 2,
        explanation: "HTTPS (HTTP sur TLS) écoute généralement sur le port 443."
      }
    ]
  },
  fondamentaux: {
    id: "quiz-fondamentaux",
    title: "Quiz Fondamentaux",
    moduleId: "fondamentaux",
    xp: 20,
    questions: [
      {
        id: "q1",
        type: "mcq",
        question: "La RAM est :",
        options: [
          "Un stockage permanent",
          "Une mémoire volatile utilisée pendant l'exécution",
          "Un processeur graphique",
          "Un périphérique d'entrée"
        ],
        correct: 1,
        explanation: "La RAM (mémoire vive) est volatile : son contenu est perdu à l'extinction."
      },
      {
        id: "q2",
        type: "truefalse",
        question: "Un processus peut contenir plusieurs threads.",
        correct: true,
        explanation: "Un processus est un conteneur ; les threads sont les unités d'exécution à l'intérieur."
      },
      {
        id: "q3",
        type: "mcq",
        question: "Les privilèges élevés (administrateur) permettent notamment de :",
        options: [
          "Uniquement surfer sur Internet",
          "Modifier la configuration système et gérer les autres comptes",
          "Uniquement lire les fichiers utilisateur",
          "Rien de particulier"
        ],
        correct: 1,
        explanation: "Un compte admin peut installer des logiciels, gérer les services, les utilisateurs, etc."
      }
    ]
  },
  malware: {
    id: "quiz-malware",
    title: "Quiz Analyse de malware",
    moduleId: "malware",
    xp: 20,
    questions: [
      {
        id: "q1",
        type: "mcq",
        question: "L'analyse statique consiste à :",
        options: [
          "Exécuter le malware dans une VM",
          "Étudier le fichier sans l'exécuter (hash, strings, imports...)",
          "Envoyer le fichier sur Internet",
          "Le supprimer immédiatement"
        ],
        correct: 1,
        explanation: "Statique = sans exécution. Dynamique = observation du comportement en environnement isolé."
      },
      {
        id: "q2",
        type: "truefalse",
        question: "Dans le lab FAKE STEALER de CYBER LAB, de vraies données Wi-Fi sont extraites.",
        correct: false,
        explanation: "Uniquement des données fictives (FAKE_WIFI_PASSWORD=NotARealPassword123, etc.). Aucune donnée réelle n'est lue."
      },
      {
        id: "q3",
        type: "mcq",
        question: "Un IOC (Indicator of Compromise) peut être :",
        options: [
          "Uniquement une adresse IP",
          "Un hash, un nom de domaine, une chaîne de caractères, un comportement...",
          "Uniquement un nom de fichier",
          "Un certificat de formation"
        ],
        correct: 1,
        explanation: "Les IOC sont très variés : hash, IP, domaine, registry key, mutex, comportement réseau, etc."
      }
    ]
  }
};
