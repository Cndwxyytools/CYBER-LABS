/**
 * CYBER LAB — Structure des modules et cours
 * Contenu pédagogique progressif
 */
const MODULES = [
  {
    id: "fondamentaux",
    num: "01",
    title: "Fondamentaux informatiques",
    icon: "💻",
    level: 1,
    description: "Comprendre comment fonctionne un ordinateur, le système d'exploitation, les processus et les privilèges.",
    courses: [
      { id: "ordi", title: "Comment fonctionne un ordinateur", duration: "15 min", xp: 10 },
      { id: "cpu", title: "Le processeur (CPU)", duration: "12 min", xp: 10 },
      { id: "ram", title: "La mémoire vive (RAM)", duration: "10 min", xp: 10 },
      { id: "stockage", title: "Le stockage", duration: "12 min", xp: 10 },
      { id: "gpu", title: "Le GPU", duration: "8 min", xp: 10 },
      { id: "os", title: "Le système d'exploitation", duration: "20 min", xp: 10 },
      { id: "processus", title: "Processus et threads", duration: "18 min", xp: 10 },
      { id: "fichiers", title: "Fichiers et dossiers", duration: "12 min", xp: 10 },
      { id: "permissions", title: "Permissions et utilisateurs", duration: "15 min", xp: 10 },
      { id: "privileges", title: "Notions de privilèges", duration: "15 min", xp: 10 }
    ]
  },
  {
    id: "windows",
    num: "02",
    title: "Windows",
    icon: "🪟",
    level: 1,
    description: "Architecture Windows, utilisateurs, services, registre, événements et outils d'administration.",
    courses: [
      { id: "win-arch", title: "Architecture Windows", duration: "20 min", xp: 10 },
      { id: "win-users", title: "Utilisateurs et groupes", duration: "15 min", xp: 10 },
      { id: "win-perms", title: "Permissions NTFS", duration: "15 min", xp: 10 },
      { id: "win-services", title: "Services Windows", duration: "18 min", xp: 10 },
      { id: "win-process", title: "Processus Windows", duration: "15 min", xp: 10 },
      { id: "win-registry", title: "Le Registre", duration: "20 min", xp: 10 },
      { id: "win-tasks", title: "Tâches planifiées", duration: "12 min", xp: 10 },
      { id: "win-events", title: "Journaux d'événements", duration: "18 min", xp: 10 },
      { id: "win-defender", title: "Windows Defender", duration: "12 min", xp: 10 },
      { id: "win-firewall", title: "Pare-feu Windows", duration: "15 min", xp: 10 }
    ]
  },
  {
    id: "cmd",
    num: "03",
    title: "CMD — Invite de commandes",
    icon: "⌨️",
    level: 1,
    description: "Maîtrise approfondie de l'invite de commandes Windows. Chaque commande a sa fiche complète.",
    courses: [
      { id: "cmd-intro", title: "Introduction à CMD", duration: "15 min", xp: 10 },
      { id: "cmd-navigation", title: "Navigation et fichiers", duration: "25 min", xp: 10 },
      { id: "cmd-reseau", title: "Commandes réseau", duration: "30 min", xp: 10 },
      { id: "cmd-systeme", title: "Système et processus", duration: "25 min", xp: 10 },
      { id: "cmd-recherche", title: "Recherche et filtres", duration: "20 min", xp: 10 },
      { id: "cmd-automatisation", title: "Bases de l'automatisation", duration: "20 min", xp: 10 }
    ]
  },
  {
    id: "batch",
    num: "04",
    title: "Batch / Scripts .BAT",
    icon: "📜",
    level: 2,
    description: "Écrire des scripts Batch : variables, conditions, boucles, menus, logs et automatisation.",
    courses: [
      { id: "bat-premier", title: "Premier script BAT", duration: "15 min", xp: 10 },
      { id: "bat-variables", title: "Variables et environnement", duration: "20 min", xp: 10 },
      { id: "bat-conditions", title: "Conditions (if)", duration: "18 min", xp: 10 },
      { id: "bat-boucles", title: "Boucles (for)", duration: "20 min", xp: 10 },
      { id: "bat-fichiers", title: "Fichiers et redirections", duration: "18 min", xp: 10 },
      { id: "bat-menus", title: "Menus interactifs", duration: "15 min", xp: 10 },
      { id: "bat-admin", title: "Scripts d'administration", duration: "25 min", xp: 10 },
      { id: "bat-suspects", title: "Analyser un script suspect", duration: "20 min", xp: 10 }
    ]
  },
  {
    id: "powershell",
    num: "05",
    title: "PowerShell",
    icon: "💙",
    level: 2,
    description: "Cmdlets, objets, pipelines, scripts et automatisation moderne sous Windows.",
    courses: [
      { id: "ps-intro", title: "CMD vs PowerShell", duration: "15 min", xp: 10 },
      { id: "ps-cmdlets", title: "Cmdlets et pipeline", duration: "25 min", xp: 10 },
      { id: "ps-objets", title: "Tout est objet", duration: "20 min", xp: 10 },
      { id: "ps-scripts", title: "Écrire des scripts", duration: "25 min", xp: 10 },
      { id: "ps-systeme", title: "Processus, services, événements", duration: "25 min", xp: 10 },
      { id: "ps-reseau", title: "Réseau avec PowerShell", duration: "20 min", xp: 10 },
      { id: "ps-securite", title: "Sécurité et execution policy", duration: "18 min", xp: 10 }
    ]
  },
  {
    id: "python",
    num: "06",
    title: "Python pour la cybersécurité",
    icon: "🐍",
    level: 2,
    description: "Bases Python puis automatisation, parsing de logs, APIs et outils défensifs.",
    courses: [
      { id: "py-bases", title: "Variables, types, structures", duration: "25 min", xp: 10 },
      { id: "py-controle", title: "Conditions et boucles", duration: "20 min", xp: 10 },
      { id: "py-fonctions", title: "Fonctions et exceptions", duration: "20 min", xp: 10 },
      { id: "py-fichiers", title: "Fichiers, JSON, CSV", duration: "25 min", xp: 10 },
      { id: "py-requests", title: "Requêtes HTTP et APIs", duration: "25 min", xp: 10 },
      { id: "py-regex", title: "Expressions régulières", duration: "20 min", xp: 10 },
      { id: "py-logs", title: "Parsing de logs", duration: "25 min", xp: 10 },
      { id: "py-outils", title: "Créer des outils défensifs", duration: "30 min", xp: 10 }
    ]
  },
  {
    id: "reseaux",
    num: "07",
    title: "Réseaux",
    icon: "🌐",
    level: 2,
    description: "IP, DNS, TCP/UDP, ports, routage, NAT, firewall, VPN — de la théorie à l'observation.",
    courses: [
      { id: "net-intro", title: "Qu'est-ce qu'un réseau ?", duration: "15 min", xp: 10 },
      { id: "net-ip", title: "IPv4, masques et CIDR", duration: "25 min", xp: 10 },
      { id: "net-ipv6", title: "IPv6 — les bases", duration: "15 min", xp: 10 },
      { id: "net-arp", title: "ARP et adresse MAC", duration: "18 min", xp: 10 },
      { id: "net-dns", title: "DNS en profondeur", duration: "25 min", xp: 10 },
      { id: "net-tcpudp", title: "TCP, UDP et ports", duration: "25 min", xp: 10 },
      { id: "net-http", title: "HTTP et HTTPS", duration: "20 min", xp: 10 },
      { id: "net-nat", title: "NAT et passerelles", duration: "15 min", xp: 10 },
      { id: "net-firewall", title: "Pare-feu et filtrage", duration: "20 min", xp: 10 },
      { id: "net-vpn", title: "VPN — principes", duration: "15 min", xp: 10 }
    ]
  },
  {
    id: "web",
    num: "08",
    title: "Web & HTTP",
    icon: "🌍",
    level: 2,
    description: "Navigateur, serveur, headers, cookies, sessions, APIs REST et DevTools.",
    courses: [
      { id: "web-intro", title: "Internet, navigateur, serveur", duration: "15 min", xp: 10 },
      { id: "web-http", title: "Le protocole HTTP", duration: "25 min", xp: 10 },
      { id: "web-https", title: "HTTPS et TLS", duration: "20 min", xp: 10 },
      { id: "web-headers", title: "Headers HTTP", duration: "20 min", xp: 10 },
      { id: "web-cookies", title: "Cookies et sessions", duration: "18 min", xp: 10 },
      { id: "web-rest", title: "APIs REST et JSON", duration: "25 min", xp: 10 },
      { id: "web-devtools", title: "Chrome DevTools — Network", duration: "25 min", xp: 10 }
    ]
  },
  {
    id: "scraping",
    num: "09",
    title: "Scraping légal",
    icon: "📡",
    level: 3,
    description: "Récupérer des données publiques de façon éthique : HTTP, parsing, robots.txt, rate limiting.",
    courses: [
      { id: "scrape-http", title: "Requêtes HTTP pour le scraping", duration: "20 min", xp: 10 },
      { id: "scrape-html", title: "Parser le HTML", duration: "25 min", xp: 10 },
      { id: "scrape-ethics", title: "Éthique, robots.txt et CGU", duration: "15 min", xp: 10 },
      { id: "scrape-lab", title: "Lab : site de démonstration", duration: "30 min", xp: 10 }
    ]
  },
  {
    id: "osint",
    num: "10",
    title: "OSINT",
    icon: "🔎",
    level: 3,
    description: "Renseignement en sources ouvertes : recherche avancée, DNS, WHOIS, archives, corrélation.",
    courses: [
      { id: "osint-def", title: "Qu'est-ce que l'OSINT ?", duration: "15 min", xp: 10 },
      { id: "osint-search", title: "Recherche avancée et opérateurs", duration: "25 min", xp: 10 },
      { id: "osint-dns", title: "DNS, WHOIS et domaines", duration: "25 min", xp: 10 },
      { id: "osint-archives", title: "Archives web et métadonnées", duration: "20 min", xp: 10 },
      { id: "osint-images", title: "Recherche d'images", duration: "15 min", xp: 10 },
      { id: "osint-report", title: "Rédiger un rapport OSINT", duration: "20 min", xp: 10 },
      { id: "osint-ethics", title: "Limites éthiques et légales", duration: "15 min", xp: 10 }
    ]
  },
  {
    id: "pentest",
    num: "11",
    title: "Pentest légal",
    icon: "🎯",
    level: 4,
    description: "Méthodologie professionnelle : scope, reconnaissance, énumération, validation, rapport, remédiation.",
    courses: [
      { id: "pt-methodo", title: "Méthodologie et scope", duration: "20 min", xp: 10 },
      { id: "pt-recon", title: "Reconnaissance", duration: "25 min", xp: 10 },
      { id: "pt-enum", title: "Énumération", duration: "25 min", xp: 10 },
      { id: "pt-web", title: "Tests Web (lab)", duration: "30 min", xp: 10 },
      { id: "pt-report", title: "Rapport et remédiation", duration: "20 min", xp: 10 },
      { id: "pt-ethics", title: "Cadre légal et éthique", duration: "15 min", xp: 10 }
    ]
  },
  {
    id: "malware",
    num: "12",
    title: "Analyse de malware",
    icon: "🦠",
    level: 4,
    description: "Analyse statique et dynamique, IOC, hash, strings, et lab FAKE STEALER 100 % inoffensif.",
    courses: [
      { id: "mw-types", title: "Types de malware", duration: "20 min", xp: 10 },
      { id: "mw-statique", title: "Analyse statique", duration: "30 min", xp: 10 },
      { id: "mw-dynamique", title: "Analyse dynamique", duration: "30 min", xp: 10 },
      { id: "mw-ioc", title: "Indicateurs de compromission", duration: "25 min", xp: 10 },
      { id: "mw-fake", title: "Lab FAKE STEALER", duration: "40 min", xp: 10 }
    ]
  },
  {
    id: "blueteam",
    num: "13",
    title: "Blue Team / Défense",
    icon: "🛡️",
    level: 4,
    description: "Logs, SIEM, détection, EDR, réponse à incident et chasse aux menaces.",
    courses: [
      { id: "bt-logs", title: "Journaux et monitoring", duration: "25 min", xp: 10 },
      { id: "bt-siem", title: "SIEM — principes", duration: "20 min", xp: 10 },
      { id: "bt-ioc", title: "Détection par IOC", duration: "25 min", xp: 10 },
      { id: "bt-edr", title: "Antivirus et EDR", duration: "20 min", xp: 10 },
      { id: "bt-ir", title: "Réponse à incident", duration: "30 min", xp: 10 }
    ]
  },
  {
    id: "ia",
    num: "14",
    title: "IA + Cybersécurité",
    icon: "🤖",
    level: 5,
    description: "Classification d'événements, détection d'anomalies et modèles locaux sur données fictives.",
    courses: [
      { id: "ia-intro", title: "ML pour la détection", duration: "20 min", xp: 10 },
      { id: "ia-features", title: "Features à partir de logs", duration: "25 min", xp: 10 },
      { id: "ia-lab", title: "Lab : classer des événements", duration: "35 min", xp: 10 }
    ]
  }
];

const LEVELS = [
  { id: 1, name: "Initiation", color: "green", icon: "🟢", desc: "Comprendre les bases." },
  { id: 2, name: "Débutant", color: "blue", icon: "🔵", desc: "Commencer à manipuler." },
  { id: 3, name: "Intermédiaire", color: "purple", icon: "🟣", desc: "Automatisation et analyse." },
  { id: 4, name: "Avancé", color: "orange", icon: "🟠", desc: "Analyse réseau, Web, sécurité." },
  { id: 5, name: "Expert Lab", color: "red", icon: "🔴", desc: "Labs complexes et méthodologie." },
  { id: 6, name: "Cyber Pro", color: "gray", icon: "⚫", desc: "Architecture, défense, investigation." }
];

/** Contenu détaillé de quelques cours clés (les autres ont un template riche) */
const LESSON_CONTENT = {
  "cmd-intro": {
    title: "Introduction à CMD",
    sections: [
      {
        title: "Qu'est-ce que l'invite de commandes ?",
        html: `<p>L'<strong>Invite de commandes</strong> (cmd.exe) est l'interpréteur de commandes historique de Windows. Elle permet d'exécuter des programmes, de manipuler des fichiers et d'administrer le système sans interface graphique.</p>
        <p>Contrairement à PowerShell (orienté objets), CMD travaille principalement avec du <strong>texte</strong> : chaque commande produit ou consomme des chaînes de caractères.</p>
        <p>Pourquoi l'apprendre encore aujourd'hui ?</p>
        <ul>
          <li>Elle est présente sur <strong>toutes</strong> les versions de Windows</li>
          <li>De nombreux scripts d'administration et d'installation l'utilisent encore</li>
          <li>En cybersécurité, c'est un outil de <em>living-off-the-land</em> : les attaquants comme les défenseurs s'en servent</li>
          <li>Comprendre CMD facilite l'apprentissage de Batch et de PowerShell</li>
        </ul>`
      },
      {
        title: "Lancer CMD",
        html: `<p>Plusieurs façons :</p>
        <ul>
          <li><kbd>Win + R</kbd> puis taper <code>cmd</code></li>
          <li>Menu Démarrer → rechercher « Invite de commandes »</li>
          <li>Dans l'Explorateur : taper <code>cmd</code> dans la barre d'adresse</li>
          <li>Clic droit sur le menu Démarrer → Terminal / Invite de commandes</li>
        </ul>
        <p>Pour des actions administratives, lancez une <strong>Invite en tant qu'administrateur</strong> (clic droit → Exécuter en tant qu'administrateur).</p>`
      },
      {
        title: "Le prompt",
        html: `<p>Par défaut vous voyez quelque chose comme :</p>
        <pre>C:\\Users\\student></pre>
        <p>Cela indique le <strong>répertoire de travail courant</strong> (cwd). Toutes les commandes relatives (dir, type fichier.txt...) s'appliquent à ce dossier.</p>
        <p>Le caractère <code>></code> sépare le chemin de la zone de saisie.</p>`
      },
      {
        title: "Aide intégrée",
        html: `<p>Deux réflexes indispensables :</p>
        <pre>help
help dir
dir /?</pre>
        <p><code>help</code> liste les commandes internes. <code>commande /?</code> affiche l'aide de la plupart des utilitaires.</p>`
      }
    ],
    exercise: {
      objective: "Ouvrir CMD et afficher l'aide de la commande dir.",
      steps: "Lancez cmd, tapez help dir ou dir /? et lisez les options principales.",
      solution: "dir /?"
    },
    summary: "CMD est l'interpréteur texte de Windows. Maîtrisez le prompt, l'aide (/?) et la notion de répertoire courant avant d'aller plus loin."
  },
  "cmd-navigation": {
    title: "Navigation et fichiers",
    sections: [
      {
        title: "Se déplacer",
        html: `<p>Les commandes essentielles :</p>
        <ul>
          <li><code>cd</code> — change de dossier</li>
          <li><code>cd ..</code> — remonte d'un niveau</li>
          <li><code>cd \\</code> — racine du lecteur</li>
          <li><code>dir</code> — liste le contenu</li>
          <li><code>tree</code> — arborescence</li>
        </ul>
        <p>Consultez les fiches détaillées de chaque commande dans la section <strong>Cheatsheet / Commandes</strong>.</p>`
      },
      {
        title: "Créer, copier, supprimer",
        html: `<p><code>mkdir</code>, <code>copy</code>, <code>move</code>, <code>del</code>, <code>rmdir</code>, <code>ren</code>, <code>type</code>, <code>echo</code> forment le socle de la manipulation de fichiers en ligne de commande.</p>
        <p>Entraînez-vous dans un dossier de test dédié pour éviter toute suppression accidentelle.</p>`
      }
    ],
    exercise: {
      objective: "Créer un dossier Labs, y entrer, créer un fichier notes.txt et afficher son contenu.",
      steps: "mkdir, cd, echo, type",
      solution: "mkdir Labs\ncd Labs\necho Bienvenue dans CYBER LAB > notes.txt\ntype notes.txt"
    },
    summary: "Navigation (cd, dir, tree) + CRUD fichiers (mkdir, copy, move, del, type, echo) = autonomie dans le système de fichiers."
  },
  "cmd-reseau": {
    title: "Commandes réseau",
    sections: [
      {
        title: "Diagnostic de base",
        html: `<p>En cas de problème réseau, l'ordre classique est :</p>
        <ol>
          <li><code>ipconfig /all</code> — ai-je une IP valide ?</li>
          <li><code>ping</code> passerelle puis 8.8.8.8 — connectivité ?</li>
          <li><code>nslookup</code> — résolution DNS ?</li>
          <li><code>tracert</code> — où ça bloque ?</li>
          <li><code>netstat -ano</code> — qui écoute / qui se connecte ?</li>
        </ol>
        <p>Chaque commande a sa fiche complète dans le Cheatsheet.</p>`
      }
    ],
    exercise: {
      objective: "Obtenir votre configuration IP complète et pinger votre passerelle.",
      steps: "ipconfig /all puis identifier Default Gateway, ensuite ping cette IP.",
      solution: "ipconfig /all\nping <votre_passerelle>"
    },
    summary: "ipconfig, ping, tracert, nslookup, netstat, arp forment la boîte à outils réseau de base sous Windows."
  },
  "net-ip": {
    title: "IPv4, masques et CIDR",
    sections: [
      {
        title: "Adresse IPv4",
        html: `<p>Une adresse IPv4 est composée de <strong>4 octets</strong> (32 bits), notés en décimal : <code>192.168.1.10</code>.</p>
        <p>Elle se divise en partie <strong>réseau</strong> et partie <strong>hôte</strong>, séparées par le masque de sous-réseau.</p>`
      },
      {
        title: "Masque et CIDR",
        html: `<p>Le masque <code>255.255.255.0</code> (équivalent <code>/24</code> en CIDR) signifie que les 24 premiers bits identifient le réseau, les 8 derniers l'hôte.</p>
        <p>Exemples courants :</p>
        <ul>
          <li><code>/8</code> → 255.0.0.0 (très grand réseau)</li>
          <li><code>/16</code> → 255.255.0.0</li>
          <li><code>/24</code> → 255.255.255.0 (256 adresses, 254 utilisables)</li>
          <li><code>/32</code> → une seule adresse (hôte)</li>
        </ul>`
      },
      {
        title: "Adresses privées",
        html: `<p>RFC 1918 réserve des plages non routables sur Internet :</p>
        <ul>
          <li>10.0.0.0/8</li>
          <li>172.16.0.0/12</li>
          <li>192.168.0.0/16</li>
        </ul>
        <p>Votre box domestique utilise presque toujours une de ces plages.</p>`
      }
    ],
    exercise: {
      objective: "À partir de ipconfig, déterminer le réseau de votre machine (adresse réseau + masque).",
      steps: "Notez IPv4 et masque, calculez l'adresse réseau.",
      solution: "Exemple : 192.168.1.42 / 255.255.255.0 → réseau 192.168.1.0/24"
    },
    summary: "IPv4 = 32 bits. Masque/CIDR sépare réseau et hôte. Les plages privées ne sortent pas sur Internet sans NAT."
  },
  "mw-fake": {
    title: "Lab FAKE STEALER",
    sections: [
      {
        title: "Objectif pédagogique",
        html: `<p>Ce lab enseigne les <strong>concepts</strong> derrière un stealer sans jamais manipuler de vraies données sensibles.</p>
        <p>Le programme fictif :</p>
        <ol>
          <li>Lit uniquement des variables <strong>fictives</strong> (fake_username, fake_password...)</li>
          <li>Construit un faux rapport</li>
          <li>Le transforme en JSON</li>
          <li>Simule une « transmission » vers un serveur de lab local</li>
          <li>Affiche ce qui aurait été envoyé</li>
          <li>Vous permet d'étudier les IOC côté défenseur</li>
        </ol>
        <p class="text-accent"><strong>Règle absolue :</strong> aucune donnée réelle (Wi-Fi, cookies, tokens, mots de passe) n'est lue ou exfiltrée.</p>`
      },
      {
        title: "Données fictives utilisées",
        html: `<pre>FAKE_WIFI_NAME=CyberLab_Test
FAKE_WIFI_PASSWORD=NotARealPassword123
FAKE_USERNAME=student
FAKE_PC=LAB-PC
FAKE_TOKEN=fake-token-0000-demo</pre>`
      },
      {
        title: "Comment le défenseur détecte",
        html: `<ul>
          <li><strong>Fichiers</strong> : création d'un rapport JSON dans un dossier temporaire inhabituel</li>
          <li><strong>Processus</strong> : un script Batch/Python qui enchaîne lecture → JSON → HTTP</li>
          <li><strong>Réseau</strong> : connexion sortante vers un endpoint non légitime</li>
          <li><strong>IOC</strong> : hash du script, noms de variables, User-Agent particulier</li>
        </ul>
        <p>Allez dans le <strong>Lab FAKE STEALER</strong> pour l'expérience interactive.</p>`
      }
    ],
    exercise: {
      objective: "Dans le lab, lancer la simulation et identifier au moins 3 IOC potentiels.",
      steps: "Ouvrir Labs → FAKE STEALER → Exécuter la simulation.",
      solution: "IOC exemples : fichier report_fake.json, processus batch, POST vers /lab/exfil, chaîne NotARealPassword123 dans les strings."
    },
    summary: "On apprend les mécanismes d'un stealer via une simulation 100 % inoffensive, puis on bascule en mode défenseur pour détecter les mêmes comportements."
  },
  "osint-def": {
    title: "Qu'est-ce que l'OSINT ?",
    sections: [
      {
        title: "Définition",
        html: `<p>L'<strong>OSINT</strong> (Open Source Intelligence) est la collecte et l'analyse d'informations provenant de sources <em>publiquement accessibles</em>.</p>
        <p>Cela inclut : moteurs de recherche, réseaux sociaux publics, registres DNS/WHOIS, archives web, documents publiés, images, etc.</p>
        <p>Ce n'est <strong>pas</strong> du piratage : on n'exploite aucune vulnérabilité, on ne contourne aucune authentification.</p>`
      },
      {
        title: "Cadre éthique",
        html: `<p>Dans CYBER LAB :</p>
        <ul>
          <li>Nous travaillons uniquement sur des <strong>données et cibles fictives</strong> ou des informations publiques d'organisations qui les exposent volontairement</li>
          <li>Jamais de collecte d'informations privées sur des particuliers</li>
          <li>Toujours respecter les conditions d'utilisation des plateformes</li>
        </ul>`
      }
    ],
    exercise: {
      objective: "Lister 5 sources OSINT légitimes que vous connaissez déjà.",
      steps: "Réfléchissez aux outils du quotidien (Google, LinkedIn public, WHOIS...).",
      solution: "Exemples : Google, Bing, archive.org, whois.icann.org, LinkedIn (profils publics), registres d'entreprises, certificats TLS publics (crt.sh)."
    },
    summary: "OSINT = renseignement en sources ouvertes. Légal et éthique si on reste sur du public et qu'on respecte les CGU."
  }
};

/** Génère un contenu template riche pour les cours sans contenu custom */
function getLessonContent(moduleId, courseId) {
  if (LESSON_CONTENT[courseId]) return LESSON_CONTENT[courseId];
  const mod = MODULES.find(m => m.id === moduleId);
  const course = mod?.courses.find(c => c.id === courseId);
  if (!course) return null;
  return {
    title: course.title,
    sections: [
      {
        title: "Objectifs d'apprentissage",
        html: `<p>À la fin de ce cours, vous serez capable d'expliquer le concept <strong>${course.title}</strong> et de l'appliquer dans un contexte de laboratoire contrôlé.</p>
        <p>Ce module fait partie de <em>${mod.title}</em> (niveau ${mod.level}).</p>`
      },
      {
        title: "Contenu principal",
        html: `<p>Le concept <strong>${course.title}</strong> est un pilier de la progression CYBER LAB.</p>
        <p>Nous couvrons : la définition, le fonctionnement interne, des exemples concrets, les commandes ou outils associés, les erreurs fréquentes, et l'angle cybersécurité (usage légitime / détection).</p>
        <p>Utilisez le <strong>Terminal Lab</strong> et les fiches commandes pour expérimenter en parallèle.</p>`
      },
      {
        title: "Bonnes pratiques",
        html: `<ul>
          <li>Travaillez toujours dans un environnement de lab isolé</li>
          <li>Documentez ce que vous observez</li>
          <li>Reliez chaque notion à un scénario de défense ou d'analyse</li>
        </ul>`
      }
    ],
    exercise: {
      objective: `Résumer en 3 points clés le cours « ${course.title} ».`,
      steps: "Relisez les sections puis notez vos 3 points dans Notes.",
      solution: "Les points dépendent du cours ; l'important est de reformuler avec vos mots."
    },
    summary: `${course.title} — notion essentielle du module ${mod.title}.`
  };
}
