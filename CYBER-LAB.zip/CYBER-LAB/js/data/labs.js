/**
 * CYBER LAB — Labs & Missions
 */
const LABS = [
  {
    id: "fake-stealer",
    title: "FAKE STEALER Lab",
    icon: "🦠",
    level: 4,
    xp: 50,
    moduleId: "malware",
    description: "Simulation 100% inoffensive d'un stealer. Données fictives uniquement. Objectif : comprendre le flux et identifier les IOC côté défense.",
    type: "malware"
  },
  {
    id: "http-inspector",
    title: "HTTP Request Inspector",
    icon: "🌍",
    level: 2,
    xp: 50,
    moduleId: "web",
    description: "Observez une requête HTTP fictive complète : méthode, URL, headers, body, réponse.",
    type: "web"
  },
  {
    id: "network-diag",
    title: "Diagnostic réseau simulé",
    icon: "🌐",
    level: 2,
    xp: 50,
    moduleId: "reseaux",
    description: "Scénario de panne réseau fictif : utilisez les commandes du terminal pour diagnostiquer.",
    type: "network"
  },
  {
    id: "osint-case",
    title: "Enquête OSINT fictive",
    icon: "🔎",
    level: 3,
    xp: 50,
    moduleId: "osint",
    description: "Résolvez une enquête sur une entreprise et un domaine fictifs à partir de sources simulées.",
    type: "osint"
  },
  {
    id: "ai-classify",
    title: "Classification d'événements (IA)",
    icon: "🤖",
    level: 5,
    xp: 50,
    moduleId: "ia",
    description: "Classez des événements fictifs (LOGIN, FILE_ACCESS...) en NORMAL ou SUSPICIOUS.",
    type: "ai"
  }
];

const MISSIONS = [
  {
    id: "m1",
    title: "Analyste système",
    icon: "🖥️",
    level: 2,
    xp: 100,
    description: "Utiliser CMD, fichiers, processus et réseau pour dresser un inventaire de la machine de lab.",
    objectives: ["whoami + hostname", "tasklist filtré", "ipconfig /all", "netstat -ano"]
  },
  {
    id: "m2",
    title: "Network Analyst",
    icon: "🌐",
    level: 2,
    xp: 100,
    description: "Analyser IP, DNS, ports et connexions sur un scénario fictif.",
    objectives: ["Identifier le réseau", "Tester la connectivité", "Lister les ports en écoute", "Résoudre un nom"]
  },
  {
    id: "m3",
    title: "Web Analyst",
    icon: "🌍",
    level: 3,
    xp: 100,
    description: "Analyser une requête HTTP fictive complète.",
    objectives: ["Identifier la méthode", "Lire les headers", "Comprendre le status code", "Repérer un cookie de session"]
  },
  {
    id: "m4",
    title: "OSINT Investigator",
    icon: "🔎",
    level: 3,
    xp: 100,
    description: "Résoudre une enquête fictive à partir de sources publiques simulées.",
    objectives: ["WHOIS du domaine", "Records DNS", "Archives", "Rédiger 5 findings"]
  },
  {
    id: "m5",
    title: "Malware Analyst",
    icon: "🦠",
    level: 4,
    xp: 100,
    description: "Analyser le FAKE STEALER : statique + dynamique simulée + IOC.",
    objectives: ["Lancer la simulation", "Extraire les strings fictives", "Lister 5 IOC", "Proposer des règles de détection"]
  },
  {
    id: "m6",
    title: "Blue Team",
    icon: "🛡️",
    level: 4,
    xp: 100,
    description: "Trouver les IOC du scénario FAKE STEALER et proposer une réponse.",
    objectives: ["Fichiers suspects", "Processus", "Connexion réseau", "Plan de remédiation"]
  }
];

const CTFS = [
  {
    id: "ctf1",
    title: "LAB-SERVER-01",
    status: "ONLINE",
    difficulty: "Facile",
    xp: 150,
    description: "Trouvez un indice caché dans des fichiers fictifs du terminal de simulation.",
    flag: "CYBERLAB{first_flag_welcome}"
  },
  {
    id: "ctf2",
    title: "DNS Mystery",
    status: "ONLINE",
    difficulty: "Moyen",
    xp: 150,
    description: "À partir d'enregistrements DNS fictifs, reconstituez le sous-domaine secret.",
    flag: "CYBERLAB{dns_sub_secret}"
  }
];

const BADGES = [
  { id: "first-command", name: "First Command", icon: "🖥️", desc: "Première commande dans le terminal" },
  { id: "network-explorer", name: "Network Explorer", icon: "🌐", desc: "Module Réseaux commencé" },
  { id: "batch-beginner", name: "Batch Beginner", icon: "⌨️", desc: "Premier script Batch" },
  { id: "python-coder", name: "Python Coder", icon: "🐍", desc: "Module Python commencé" },
  { id: "osint-investigator", name: "OSINT Investigator", icon: "🔎", desc: "Mission OSINT terminée" },
  { id: "lab-analyst", name: "Lab Analyst", icon: "🧪", desc: "3 labs terminés" },
  { id: "blue-team", name: "Blue Team", icon: "🛡️", desc: "Module défense terminé" },
  { id: "malware-analyst", name: "Malware Analyst", icon: "🦠", desc: "Lab FAKE STEALER terminé" },
  { id: "ai-explorer", name: "AI Explorer", icon: "🤖", desc: "Lab IA terminé" },
  { id: "cyber-master", name: "Cyber Lab Master", icon: "🏆", desc: "500 XP atteints" }
];
