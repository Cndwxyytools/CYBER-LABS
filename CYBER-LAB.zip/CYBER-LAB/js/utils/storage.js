/**
 * CYBER LAB — Persistence (localStorage)
 */
const STORAGE_KEY = "cyberlab_progress_v1";

const DEFAULT_PROGRESS = {
  xp: 0,
  level: 1,
  completedCourses: [],
  completedLabs: [],
  completedMissions: [],
  completedCTFs: [],
  quizScores: {},
  favorites: { courses: [], commands: [], labs: [] },
  notes: {},
  badges: [],
  lastCourse: null,
  learningTimeMin: 0,
  createdAt: null,
  updatedAt: null
};

function loadProgress() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      const p = { ...DEFAULT_PROGRESS, createdAt: new Date().toISOString() };
      saveProgress(p);
      return p;
    }
    return { ...DEFAULT_PROGRESS, ...JSON.parse(raw) };
  } catch (e) {
    console.warn("Progress load error", e);
    return { ...DEFAULT_PROGRESS };
  }
}

function saveProgress(data) {
  data.updatedAt = new Date().toISOString();
  // Level from XP
  if (data.xp >= 2000) data.level = 6;
  else if (data.xp >= 1200) data.level = 5;
  else if (data.xp >= 700) data.level = 4;
  else if (data.xp >= 350) data.level = 3;
  else if (data.xp >= 100) data.level = 2;
  else data.level = 1;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  return data;
}

function addXP(amount, reason) {
  const p = loadProgress();
  p.xp += amount;
  saveProgress(p);
  if (typeof showToast === "function") {
    showToast(`+${amount} XP${reason ? " — " + reason : ""}`, "xp");
  }
  // Badges
  if (p.xp >= 500 && !p.badges.includes("cyber-master")) {
    p.badges.push("cyber-master");
    saveProgress(p);
  }
  return p;
}

function completeCourse(courseId) {
  const p = loadProgress();
  if (!p.completedCourses.includes(courseId)) {
    p.completedCourses.push(courseId);
    p.lastCourse = courseId;
    saveProgress(p);
    addXP(10, "Cours terminé");
  }
  return p;
}

function completeLab(labId) {
  const p = loadProgress();
  if (!p.completedLabs.includes(labId)) {
    p.completedLabs.push(labId);
    saveProgress(p);
    addXP(50, "Lab terminé");
    if (labId === "fake-stealer" && !p.badges.includes("malware-analyst")) {
      p.badges.push("malware-analyst");
      saveProgress(p);
    }
    if (p.completedLabs.length >= 3 && !p.badges.includes("lab-analyst")) {
      p.badges.push("lab-analyst");
      saveProgress(p);
    }
  }
  return p;
}

function completeMission(missionId) {
  const p = loadProgress();
  if (!p.completedMissions.includes(missionId)) {
    p.completedMissions.push(missionId);
    saveProgress(p);
    addXP(100, "Mission terminée");
  }
  return p;
}

function saveQuizScore(quizId, score, total) {
  const p = loadProgress();
  p.quizScores[quizId] = { score, total, at: new Date().toISOString() };
  saveProgress(p);
  if (score / total >= 0.7) addXP(20, "Quiz réussi");
  return p;
}

function toggleFavorite(type, id) {
  const p = loadProgress();
  if (!p.favorites[type]) p.favorites[type] = [];
  const idx = p.favorites[type].indexOf(id);
  if (idx >= 0) p.favorites[type].splice(idx, 1);
  else p.favorites[type].push(id);
  saveProgress(p);
  return p;
}

function saveNote(courseId, text) {
  const p = loadProgress();
  p.notes[courseId] = text;
  saveProgress(p);
  return p;
}

function resetProgress() {
  localStorage.removeItem(STORAGE_KEY);
  return loadProgress();
}

function exportProgress() {
  return JSON.stringify(loadProgress(), null, 2);
}

function importProgress(jsonStr) {
  try {
    const data = JSON.parse(jsonStr);
    saveProgress({ ...DEFAULT_PROGRESS, ...data });
    return true;
  } catch {
    return false;
  }
}
