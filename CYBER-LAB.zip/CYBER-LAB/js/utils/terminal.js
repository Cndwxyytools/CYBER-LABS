/**
 * CYBER LAB — Terminal de simulation (aucune commande réelle)
 */
class SimulatedTerminal {
  constructor(containerEl) {
    this.container = containerEl;
    this.cwd = "C:\\Users\\student";
    this.history = [];
    this.historyIdx = -1;
    this.fs = this._buildFS();
    this.env = {
      USERNAME: "student",
      COMPUTERNAME: "LAB-PC",
      USERPROFILE: "C:\\Users\\student",
      PATH: "C:\\Windows\\system32;C:\\Windows"
    };
  }

  _buildFS() {
    return {
      "C:\\": { type: "dir", children: ["Users", "Windows", "Labs"] },
      "C:\\Users": { type: "dir", children: ["student", "Public"] },
      "C:\\Users\\student": { type: "dir", children: ["Documents", "Desktop", "notes.txt", "Labs"] },
      "C:\\Users\\student\\Documents": { type: "dir", children: [] },
      "C:\\Users\\student\\Desktop": { type: "dir", children: [] },
      "C:\\Users\\student\\notes.txt": { type: "file", content: "Bienvenue dans CYBER LAB !\nCeci est un fichier de démonstration." },
      "C:\\Users\\student\\Labs": { type: "dir", children: ["fake_report.json", "readme.txt"] },
      "C:\\Users\\student\\Labs\\readme.txt": { type: "file", content: "Dossier de laboratoire CYBER LAB.\nAucune donnée réelle ici." },
      "C:\\Users\\student\\Labs\\fake_report.json": {
        type: "file",
        content: JSON.stringify({
          fake_username: "student",
          fake_pc: "LAB-PC",
          fake_wifi_name: "CyberLab_Test",
          fake_wifi_password: "NotARealPassword123",
          fake_token: "fake-token-0000-demo",
          note: "DONNÉES FICTIVES UNIQUEMENT"
        }, null, 2)
      },
      "C:\\Windows": { type: "dir", children: ["System32"] },
      "C:\\Windows\\System32": { type: "dir", children: ["drivers"] },
      "C:\\Labs": { type: "dir", children: ["CTF"] },
      "C:\\Labs\\CTF": { type: "dir", children: ["flag.txt", "hint.txt"] },
      "C:\\Labs\\CTF\\flag.txt": { type: "file", content: "CYBERLAB{first_flag_welcome}" },
      "C:\\Labs\\CTF\\hint.txt": { type: "file", content: "Le flag est dans flag.txt. Cherchez bien !" }
    };
  }

  render() {
    this.container.innerHTML = `
      <div class="terminal-container">
        <div class="terminal-header">
          <span class="terminal-dot red"></span>
          <span class="terminal-dot yellow"></span>
          <span class="terminal-dot green"></span>
          <span class="terminal-title">TERMINAL DE SIMULATION — aucune commande n'est exécutée sur le système réel</span>
        </div>
        <div class="terminal-body" id="term-body">
          <div class="terminal-line terminal-info">CYBER LAB Terminal v1.0 — Tapez help pour la liste des commandes</div>
          <div class="terminal-line terminal-warning">⚠️ Simulation locale uniquement. Aucun accès au système hôte.</div>
        </div>
      </div>
    `;
    this.body = this.container.querySelector("#term-body");
    this._addInputLine();
  }

  _addInputLine() {
    const line = document.createElement("div");
    line.className = "terminal-input-line";
    line.innerHTML = `<span class="terminal-prompt">${this.cwd}&gt;</span><input type="text" class="terminal-input" autocomplete="off" spellcheck="false" />`;
    this.body.appendChild(line);
    const input = line.querySelector("input");
    input.focus();
    input.addEventListener("keydown", (e) => this._onKey(e, input, line));
  }

  _onKey(e, input, line) {
    if (e.key === "Enter") {
      const cmd = input.value.trim();
      input.disabled = true;
      if (cmd) {
        this.history.push(cmd);
        this.historyIdx = this.history.length;
        this._exec(cmd);
      }
      this._addInputLine();
      this.body.scrollTop = this.body.scrollHeight;
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      if (this.historyIdx > 0) {
        this.historyIdx--;
        input.value = this.history[this.historyIdx] || "";
      }
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      if (this.historyIdx < this.history.length - 1) {
        this.historyIdx++;
        input.value = this.history[this.historyIdx] || "";
      } else {
        this.historyIdx = this.history.length;
        input.value = "";
      }
    } else if (e.key === "Tab") {
      e.preventDefault();
      // simple autocomplete
      const partial = input.value.toLowerCase();
      const cmds = ["help","dir","cd","cls","clear","echo","type","cat","pwd","whoami","hostname","ipconfig","ping","nslookup","netstat","arp","tree","ver","systeminfo","tasklist","getmac"];
      const match = cmds.find(c => c.startsWith(partial));
      if (match) input.value = match;
    }
  }

  _print(text, cls = "terminal-output") {
    const div = document.createElement("div");
    div.className = "terminal-line " + cls;
    div.textContent = text;
    this.body.appendChild(div);
  }

  _printHTML(html, cls = "terminal-output") {
    const div = document.createElement("div");
    div.className = "terminal-line " + cls;
    div.innerHTML = html;
    this.body.appendChild(div);
  }

  _exec(raw) {
    const parts = raw.match(/(?:[^\s"]+|"[^"]*")+/g) || [];
    const cmd = (parts[0] || "").toLowerCase().replace(/"/g, "");
    const args = parts.slice(1).map(a => a.replace(/^"|"$/g, ""));

    switch (cmd) {
      case "help":
        this._print("Commandes simulées disponibles :", "terminal-info");
        this._print("  help, cls, clear, pwd, cd, dir, ls, tree, type, cat, echo");
        this._print("  whoami, hostname, ver, systeminfo, tasklist");
        this._print("  ipconfig, ping, nslookup, netstat, arp, getmac");
        this._print("  history — affiche l'historique");
        break;
      case "cls":
      case "clear":
        this.body.innerHTML = "";
        break;
      case "pwd":
        this._print(this.cwd);
        break;
      case "cd":
        this._cd(args[0] || "");
        break;
      case "dir":
      case "ls":
        this._dir(args);
        break;
      case "tree":
        this._print("C:.");
        this._print("├───Users");
        this._print("│   └───student");
        this._print("│       ├───Documents");
        this._print("│       ├───Desktop");
        this._print("│       ├───Labs");
        this._print("│       └───notes.txt");
        this._print("├───Windows");
        this._print("│   └───System32");
        this._print("└───Labs");
        this._print("    └───CTF");
        break;
      case "type":
      case "cat":
        this._type(args[0]);
        break;
      case "echo":
        this._print(args.join(" ") || "");
        break;
      case "whoami":
        this._print("lab-pc\\student");
        break;
      case "hostname":
        this._print("LAB-PC");
        break;
      case "ver":
        this._print("Microsoft Windows [Version 10.0.19045.SIMULATED]");
        break;
      case "systeminfo":
        this._print("Nom de l'hôte:                 LAB-PC");
        this._print("Nom du système d'exploitation: Microsoft Windows 10 Pro (Simulation)");
        this._print("Version du système:            10.0.19045");
        this._print("Fabricant:                     CYBER LAB");
        this._print("Processeur(s):                 1 processeur(s) installé(s)");
        this._print("Mémoire physique totale:       8 192 Mo");
        this._print("Domaine:                       WORKGROUP");
        break;
      case "tasklist":
        this._print("Nom de l'image                 PID Session Nom de session Utilisation mémoire");
        this._print("=".repeat(70));
        this._print("System Idle Process              0 Services                   8 Ko");
        this._print("System                           4 Services                 128 Ko");
        this._print("explorer.exe                  1234 Console                45 000 Ko");
        this._print("cmd.exe                       5678 Console                 4 200 Ko");
        this._print("chrome.exe                    9012 Console               120 000 Ko");
        break;
      case "ipconfig":
        this._ipconfig(args);
        break;
      case "ping":
        this._ping(args[0]);
        break;
      case "nslookup":
        this._print("Serveur :  dns.lab.local");
        this._print("Address:  192.168.1.1");
        this._print("");
        this._print("Nom :    " + (args[0] || "example.com"));
        this._print("Address:  93.184.216.34  (simulé)");
        break;
      case "netstat":
        this._print("Connexions actives (simulation)");
        this._print("  Proto  Adresse locale          Adresse distante        État           PID");
        this._print("  TCP    0.0.0.0:445             0.0.0.0:0              LISTENING      4");
        this._print("  TCP    192.168.1.42:49752      93.184.216.34:443      ESTABLISHED    9012");
        this._print("  TCP    127.0.0.1:8080          0.0.0.0:0              LISTENING      5678");
        break;
      case "arp":
        this._print("Interface : 192.168.1.42 --- 0xb");
        this._print("  Adresse Internet      Adresse physique      Type");
        this._print("  192.168.1.1           aa-bb-cc-dd-ee-01     dynamique");
        this._print("  192.168.1.255         ff-ff-ff-ff-ff-ff     statique");
        break;
      case "getmac":
        this._print("Adresse physique    Nom de transport");
        this._print("=================== ==========================================================");
        this._print("AA-BB-CC-DD-EE-FF   \\Device\\Tcpip_{SIMULATED}");
        break;
      case "history":
        this.history.forEach((h, i) => this._print(`  ${i + 1}  ${h}`));
        break;
      case "":
        break;
      default:
        this._print(`'${cmd}' n'est pas reconnu comme commande simulée. Tapez help.`, "terminal-error");
    }
  }

  _cd(path) {
    if (!path || path === "") {
      this._print(this.cwd);
      return;
    }
    if (path === "..") {
      const parts = this.cwd.split("\\").filter(Boolean);
      if (parts.length > 1) {
        parts.pop();
        this.cwd = parts.join("\\");
        if (!this.cwd.endsWith(":")) this.cwd += (parts.length === 1 ? "\\" : "");
        if (this.cwd.match(/^[A-Z]:$/)) this.cwd += "\\";
      }
      return;
    }
    if (path === "\\" || path === "/") {
      this.cwd = "C:\\";
      return;
    }
    let target;
    if (path.match(/^[A-Za-z]:/)) target = path;
    else if (path.startsWith("\\")) target = "C:" + path;
    else target = this.cwd.replace(/\\$/, "") + "\\" + path;

    target = target.replace(/\//g, "\\");
    // normalize
    if (this.fs[target] && this.fs[target].type === "dir") {
      this.cwd = target;
    } else if (this.fs[target + "\\"] && this.fs[target + "\\"].type === "dir") {
      this.cwd = target + "\\";
    } else {
      this._print("Le chemin d'accès spécifié est introuvable.", "terminal-error");
    }
  }

  _dir() {
    const key = this.cwd.endsWith("\\") ? this.cwd.slice(0, -1) : this.cwd;
    const node = this.fs[this.cwd] || this.fs[key] || this.fs[key + "\\"];
    if (!node || node.type !== "dir") {
      this._print("Répertoire introuvable.", "terminal-error");
      return;
    }
    this._print(` Répertoire de ${this.cwd}`);
    this._print("");
    (node.children || []).forEach(name => {
      const childKey = (this.cwd.endsWith("\\") ? this.cwd : this.cwd + "\\") + name;
      const child = this.fs[childKey];
      if (child && child.type === "dir") {
        this._print(`<DIR>          ${name}`);
      } else {
        this._print(`        1 024 ${name}`);
      }
    });
  }

  _type(file) {
    if (!file) {
      this._print("Spécifiez un nom de fichier.", "terminal-error");
      return;
    }
    let key = file.match(/^[A-Za-z]:/) ? file : (this.cwd.replace(/\\$/, "") + "\\" + file);
    const node = this.fs[key];
    if (!node || node.type !== "file") {
      this._print("Fichier introuvable.", "terminal-error");
      return;
    }
    this._print(node.content);
  }

  _ipconfig(args) {
    const all = args.includes("/all");
    this._print("Configuration IP de Windows (simulation)");
    this._print("");
    this._print("Carte réseau sans fil Wi-Fi :");
    this._print("   Suffixe DNS propre à la connexion. . . : lan");
    this._print("   Adresse IPv6 de liaison locale. . . . : fe80::abcd:1234:5678:9abc%12");
    this._print("   Adresse IPv4. . . . . . . . . . . . . : 192.168.1.42");
    this._print("   Masque de sous-réseau. . . . . . . . . : 255.255.255.0");
    this._print("   Passerelle par défaut. . . . . . . . . : 192.168.1.1");
    if (all) {
      this._print("   Adresse physique. . . . . . . . . . . : AA-BB-CC-DD-EE-FF");
      this._print("   DHCP activé. . . . . . . . . . . . . : Oui");
      this._print("   Serveurs DNS. . . . . . . . . . . . . : 192.168.1.1");
      this._print("                                       8.8.8.8");
    }
  }

  _ping(target) {
    target = target || "127.0.0.1";
    this._print(`Envoi d'une requête 'ping' sur ${target} avec 32 octets de données :`);
    for (let i = 0; i < 4; i++) {
      this._print(`Réponse de ${target === "8.8.8.8" ? "8.8.8.8" : "192.168.1.1"} : octets=32 temps=${12 + i * 3} ms TTL=64`);
    }
    this._print("Statistiques Ping :");
    this._print("    Paquets : envoyés = 4, reçus = 4, perdus = 0 (perte 0%)");
  }

  runCommand(cmd) {
    this._print(`${this.cwd}>${cmd}`, "terminal-prompt");
    this._exec(cmd);
    this._addInputLine();
  }
}
